-- Leaderboard Phase 5 RPCs (run in Supabase SQL editor)
-- Lua kill switch: USE_RPC in leaderboard.lua

create index if not exists scores_mode_score_desc_idx
    on public.scores (mode, score desc);

create index if not exists scores_mode_score_asc_idx
    on public.scores (mode, score asc);

create or replace function public.leaderboard_window(
    p_mode  text,
    p_score int,
    p_limit int default 10
)
returns json
language plpgsql
stable
as $$
declare
    v_total int;
    v_rank  int;
    v_start int;
    v_rows  json;
begin
    select count(*) into v_total
    from public.scores where mode = p_mode;

    -- Mirrors doFetchRank: nil/<=0 => no rank; strict > for ties.
    if p_score is null or p_score <= 0 then
        v_rank := null;
    else
        select count(*) + 1 into v_rank
        from public.scores
        where mode = p_mode and score > p_score;
    end if;

    -- Mirrors fetchLocal window clamping.
    if v_rank is null then
        v_start := greatest(1, v_total - p_limit + 1);
    else
        v_start := greatest(1, least(v_rank - 5, v_total - p_limit + 1));
    end if;

    select coalesce(json_agg(t order by t.ord), '[]'::json) into v_rows
    from (
        select player_name, score, device_id,
               row_number() over () as ord
        from public.scores
        where mode = p_mode
        order by score desc
        offset v_start - 1
        limit p_limit
    ) t;

    return json_build_object(
        'total', v_total,
        'start', v_start,
        'rank',  v_rank,
        'rows',  v_rows
    );
end
$$;

grant execute on function public.leaderboard_window(text, integer, integer) to anon, authenticated;

create or replace function public.submit_and_top(
    p_device_id        text,
    p_player_name      text,
    p_score            int,
    p_mode             text,
    p_games_played     int,
    p_avg_score        int,
    p_total_time       int,
    p_sessions_played  int,
    p_days_played      int,
    p_last_played_date text,
    p_limit            int default 10
)
returns json
language plpgsql
volatile
as $$
declare
    v_rows json;
    v_rank int;
begin
    -- Mirrors Prefer: resolution=merge-duplicates (overwrite all columns).
    insert into public.scores (
        device_id, player_name, score, mode, games_played, avg_score,
        total_time, sessions_played, days_played, last_played_date
    ) values (
        p_device_id, p_player_name, p_score, p_mode, p_games_played, p_avg_score,
        p_total_time, p_sessions_played, p_days_played, p_last_played_date
    )
    on conflict (device_id, mode) do update set
        player_name      = excluded.player_name,
        score            = excluded.score,
        games_played     = excluded.games_played,
        avg_score        = excluded.avg_score,
        total_time       = excluded.total_time,
        sessions_played  = excluded.sessions_played,
        days_played      = excluded.days_played,
        last_played_date = excluded.last_played_date;

    select coalesce(json_agg(t order by t.ord), '[]'::json) into v_rows
    from (
        select player_name, score, device_id,
               row_number() over () as ord
        from public.scores
        where mode = p_mode
        order by score desc
        limit p_limit
    ) t;

    -- Prefer index within top-N; else count query (finalizeWithEntries).
    select t.ord into v_rank
    from (
        select device_id, row_number() over () as ord
        from public.scores
        where mode = p_mode
        order by score desc
        limit p_limit
    ) t
    where t.device_id = p_device_id;

    if v_rank is null then
        if p_score is null or p_score <= 0 then
            v_rank := null;
        else
            select count(*) + 1 into v_rank
            from public.scores
            where mode = p_mode and score > p_score;
        end if;
    end if;

    return json_build_object('rank', v_rank, 'rows', v_rows);
end
$$;

grant execute on function public.submit_and_top(
    text, text, integer, text, integer, integer, integer, integer, integer, text, integer
) to anon, authenticated;

notify pgrst, 'reload schema';
