#include "c_shield.h"
#include "c_enemy.h"
#include <math.h>

static PlaydateAPI* pd = NULL;
static Shield shields[MAX_SHIELDS];
static int shieldCount = 0;

static ShieldCollisionResult shieldCollisions[MAX_SHIELD_COLLISIONS];
static int shieldCollisionCount = 0;

void shield_init(PlaydateAPI* playdate) {
    pd = playdate;
    shieldCount = 0;
    shieldCollisionCount = 0;
}

int shield_add(int type, float angle, float orbitSpeed, float orbitRadius,
               float radius, float explosionRadius, float explosionDamage,
               uint32_t stasisDuration) {
    if (shieldCount >= MAX_SHIELDS) return -1;

    Shield* s = &shields[shieldCount];
    s->x = 0;
    s->y = 0;
    s->angle = angle;
    s->orbitSpeed = orbitSpeed;
    s->orbitRadius = orbitRadius;
    s->radius = radius;
    s->explosionRadius = explosionRadius;
    s->explosionDamage = explosionDamage;
    s->stasisDuration = stasisDuration;
    s->type = (uint8_t)type;
    s->active = 1;

    return shieldCount++;
}

int shield_update(float playerX, float playerY, float timeScale) {
    shieldCollisionCount = 0;

    int eCount;
    Enemy* eArr = enemy_get_array(&eCount);

    for (int s = 0; s < shieldCount; s++) {
        Shield* shield = &shields[s];
        if (!shield->active) continue;

        /* update orbit */
        shield->angle += shield->orbitSpeed * timeScale;
        shield->x = playerX + cosf(shield->angle) * shield->orbitRadius;
        shield->y = playerY + sinf(shield->angle) * shield->orbitRadius;

        /* check collision with enemies */
        for (int e = 0; e < eCount; e++) {
            Enemy* enemy = &eArr[e];
            if (enemy->health <= 0 || enemy->destroyed) continue;

            float dx = shield->x - enemy->x;
            float dy = shield->y - enemy->y;
            float distSq = dx * dx + dy * dy;
            float rSum = shield->radius + enemy->radius;

            if (distSq < rSum * rSum) {
                if (shieldCollisionCount < MAX_SHIELD_COLLISIONS) {
                    ShieldCollisionResult* r = &shieldCollisions[shieldCollisionCount++];
                    r->shieldIndex = s;
                    r->type = shield->type;
                    r->shieldX = shield->x;
                    r->shieldY = shield->y;
                    r->explosionRadius = shield->explosionRadius;
                    r->explosionDamage = shield->explosionDamage;
                    r->stasisDuration = shield->stasisDuration;
                    r->enemyIndex = e;
                }
                shield->active = 0;
                break;
            }
        }
    }

    /* compact inactive shields */
    int w = 0;
    for (int r = 0; r < shieldCount; r++) {
        if (shields[r].active) {
            if (w != r) shields[w] = shields[r];
            w++;
        }
    }
    shieldCount = w;

    return shieldCollisionCount;
}

const ShieldCollisionResult* shield_get_collision(int index) {
    if (index < 0 || index >= shieldCollisionCount) return NULL;
    return &shieldCollisions[index];
}

void shield_clear(void) {
    shieldCount = 0;
    shieldCollisionCount = 0;
}

void shield_clear_type(int type) {
    int w = 0;
    for (int r = 0; r < shieldCount; r++) {
        if (shields[r].type != (uint8_t)type) {
            if (w != r) shields[w] = shields[r];
            w++;
        }
    }
    shieldCount = w;
}

int shield_get_count(void) {
    return shieldCount;
}

const Shield* shield_get(int index) {
    if (index < 0 || index >= shieldCount) return NULL;
    return &shields[index];
}

/* ========== Lua-callable wrappers ========== */

int c_shield_add_lua(lua_State* L) {
    int      type       = pd->lua->getArgInt(1);
    float    angle      = pd->lua->getArgFloat(2);
    float    orbitSpeed = pd->lua->getArgFloat(3);
    float    orbitR     = pd->lua->getArgFloat(4);
    float    radius     = pd->lua->getArgFloat(5);
    float    expR       = pd->lua->getArgFloat(6);
    float    expD       = pd->lua->getArgFloat(7);
    uint32_t stasDur    = (uint32_t)pd->lua->getArgInt(8);

    int idx = shield_add(type, angle, orbitSpeed, orbitR, radius, expR, expD, stasDur);
    pd->lua->pushInt(idx);
    return 1;
}

int c_shield_update_lua(lua_State* L) {
    float px = pd->lua->getArgFloat(1);
    float py = pd->lua->getArgFloat(2);
    float ts = pd->lua->getArgFloat(3);

    int hits = shield_update(px, py, ts);
    pd->lua->pushInt(hits);
    return 1;
}

/* Returns: shieldIndex, type, sx, sy, explosionRadius, explosionDamage,
            stasisDuration, enemyIndex */
int c_shield_get_collision_lua(lua_State* L) {
    int index = pd->lua->getArgInt(1);
    const ShieldCollisionResult* r = shield_get_collision(index);
    if (!r) {
        pd->lua->pushNil();
        return 1;
    }
    pd->lua->pushInt(r->shieldIndex);
    pd->lua->pushInt(r->type);
    pd->lua->pushFloat(r->shieldX);
    pd->lua->pushFloat(r->shieldY);
    pd->lua->pushFloat(r->explosionRadius);
    pd->lua->pushFloat(r->explosionDamage);
    pd->lua->pushInt((int)r->stasisDuration);
    pd->lua->pushInt(r->enemyIndex);
    return 8;
}

int c_shield_clear_lua(lua_State* L) {
    shield_clear();
    return 0;
}

int c_shield_clear_type_lua(lua_State* L) {
    int type = pd->lua->getArgInt(1);
    shield_clear_type(type);
    return 0;
}

int c_shield_get_count_lua(lua_State* L) {
    pd->lua->pushInt(shieldCount);
    return 1;
}

/* Returns: x, y, radius, type, angle, orbitSpeed, orbitRadius, explosionRadius,
            explosionDamage, stasisDuration */
int c_shield_get_lua(lua_State* L) {
    int index = pd->lua->getArgInt(1);
    const Shield* s = shield_get(index);
    if (!s) {
        pd->lua->pushNil();
        return 1;
    }
    pd->lua->pushFloat(s->x);
    pd->lua->pushFloat(s->y);
    pd->lua->pushFloat(s->radius);
    pd->lua->pushInt(s->type);
    pd->lua->pushFloat(s->angle);
    pd->lua->pushFloat(s->orbitSpeed);
    pd->lua->pushFloat(s->orbitRadius);
    pd->lua->pushFloat(s->explosionRadius);
    pd->lua->pushFloat(s->explosionDamage);
    pd->lua->pushInt((int)s->stasisDuration);
    return 10;
}
