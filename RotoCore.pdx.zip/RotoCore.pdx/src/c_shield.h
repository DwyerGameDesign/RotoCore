#ifndef C_SHIELD_H
#define C_SHIELD_H

#include "pd_api.h"
#include <stdint.h>

#define MAX_SHIELDS           6
#define MAX_SHIELD_COLLISIONS 6

typedef enum {
    SHIELD_NOVA   = 0,
    SHIELD_STASIS = 1
} ShieldType;

typedef struct {
    float x, y;
    float angle;
    float orbitSpeed;
    float orbitRadius;
    float radius;
    float explosionRadius;
    float explosionDamage;
    uint32_t stasisDuration;
    uint8_t  type;           /* ShieldType */
    uint8_t  active;
} Shield;

typedef struct {
    int      shieldIndex;
    int      type;           /* ShieldType */
    float    shieldX, shieldY;
    float    explosionRadius;
    float    explosionDamage;
    uint32_t stasisDuration;
    int      enemyIndex;
} ShieldCollisionResult;

void shield_init(PlaydateAPI* playdate);
int  shield_add(int type, float angle, float orbitSpeed, float orbitRadius,
                float radius, float explosionRadius, float explosionDamage,
                uint32_t stasisDuration);
int  shield_update(float playerX, float playerY, float timeScale);
const ShieldCollisionResult* shield_get_collision(int index);
void shield_clear(void);
void shield_clear_type(int type);
int  shield_get_count(void);
const Shield* shield_get(int index);

/* Lua-callable wrappers */
int c_shield_add_lua(lua_State* L);
int c_shield_update_lua(lua_State* L);
int c_shield_get_collision_lua(lua_State* L);
int c_shield_clear_lua(lua_State* L);
int c_shield_clear_type_lua(lua_State* L);
int c_shield_get_count_lua(lua_State* L);
int c_shield_get_lua(lua_State* L);

#endif
