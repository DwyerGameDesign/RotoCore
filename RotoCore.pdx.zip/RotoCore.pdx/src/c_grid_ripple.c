#include "c_grid_ripple.h"
#include <math.h>
#include <string.h>

#define PI_F              3.14159265f
#define GRID_SIZE         25
#define WAVE_SPEED        300.0f
#define WAVE_WIDTH        60.0f
#define AMPLITUDE         10.0f
#define RIPPLE_INTENSITY_LOW  0.15f
#define RIPPLE_INTENSITY_HIGH 0.35f
#define MAX_AGE_SAFETY    3000
#define DASHES_PER_SEGMENT 2
#define DASH_LENGTH       1
#define SCREEN_W          400
#define SCREEN_H          240
#define MAX_GRID_LINES    32
#define ACTIVE_RIPPLE_CAP   5

static PlaydateAPI* pd = NULL;

static GridRipple ripples[MAX_RIPPLES];
static int rippleCount = 0;

static int gridX[MAX_GRID_LINES];
static int gridXCount = 0;
static int gridY[MAX_GRID_LINES];
static int gridYCount = 0;

/* Grid dissolve state */
static int dissolveActive = 0;
static float dissolveOriginX = 0.0f;
static float dissolveOriginY = 0.0f;
static uint32_t dissolveStartTime = 0;
static float dissolveDuration = 1200.0f;
static float dissolveRadiusCached = 0.0f;
static float dissolveSpeed = 400.0f;

/* Grid materialize state (reverse dissolve) */
static int materializeActive = 0;
static float materializeOriginX = 0.0f;
static float materializeOriginY = 0.0f;
static uint32_t materializeStartTime = 0;
static float materializeDuration = 1000.0f;
static float materializeStartRadius = 500.0f;
static float materializeRadiusCached = 0.0f;

static int dissolveActiveThisFrame = 0;
static int materializeActiveThisFrame = 0;

/* Omit grid dashes inside this circle (screen space, includes shake in Lua) */
static int excludeZoneActive = 0;
static float excludeCx = 0.0f;
static float excludeCy = 0.0f;
static float excludeRadiusSq = 0.0f;

#define DISSOLVE_EDGE_ZONE 35.0f

/* Opt 1: Per-frame ripple constants (filled once per draw in build_frame_ripples). */
typedef struct {
    float x, y;
    float elapsed;
    float waveFront;
    float maxDistance;
    float strength;
    int inward;
    float innerBandSq;
    float outerBandSq;
    float maxReachManhattan;
    float inwardMinManhattan;
    float inwardMaxManhattan;
    int valid;
} RippleFrame;

static RippleFrame frameRipples[MAX_RIPPLES];
static int frameRippleCount = 0;

/* Opt 6: Squared dissolve/materialize radii (set once per frame in grid_ripple_draw). */
static float dissolveRadiusSq = 0.0f;
static float dissolveOuterRadiusSq = 0.0f;
static float materializeRadiusSq = 0.0f;
static float materializeOuterRadiusSq = 0.0f;

/* Post-profile opt A: Precomputed integer dash positions. The underlying grid
   never changes at runtime, so instead of recomputing ~1038 dash positions via
   float divisions every frame, we bake them once in grid_ripple_init. The V
   array holds dashes on vertical grid lines (rendered as horizontal stripes
   when intensity is medium/high); H is the reverse. */
typedef struct { int16_t x, y; } DashPos;
#define MAX_DASHES_PER_AXIS (MAX_GRID_LINES * MAX_GRID_LINES * DASHES_PER_SEGMENT)
static DashPos dashesV[MAX_DASHES_PER_AXIS];
static int dashesVCount = 0;
static DashPos dashesH[MAX_DASHES_PER_AXIS];
static int dashesHCount = 0;

/* Post-profile opt D: Per-dash accumulators for the inverted ripple loop.
   Instead of the old per-dash double-iteration over every ripple (manhattan
   gate pass + math pass), we iterate ripples on the outside. For each ripple
   we walk the dash array once and accumulate its contribution into the
   dashOffset/dashIntensity slots. A generation counter avoids memsetting each
   frame: if dashTouchGen[i] != currentFrameGen, the slot is treated as zero. */
static float dashOffsetXV[MAX_DASHES_PER_AXIS];
static float dashOffsetYV[MAX_DASHES_PER_AXIS];
static float dashIntensityV[MAX_DASHES_PER_AXIS];
static uint32_t dashTouchGenV[MAX_DASHES_PER_AXIS];

static float dashOffsetXH[MAX_DASHES_PER_AXIS];
static float dashOffsetYH[MAX_DASHES_PER_AXIS];
static float dashIntensityH[MAX_DASHES_PER_AXIS];
static uint32_t dashTouchGenH[MAX_DASHES_PER_AXIS];

static uint32_t currentFrameGen = 0;

/* Post-profile opt B: Per-frame axis-aligned bounding boxes for the various
   effects. Most dashes fall outside these boxes and can skip the expensive
   per-dash work entirely. */
static int   ripplesBBoxActive = 0;
static float ripplesBBoxMinX, ripplesBBoxMaxX, ripplesBBoxMinY, ripplesBBoxMaxY;

static int   excludeBBoxActive = 0;
static int   excludeBBoxMinX, excludeBBoxMaxX, excludeBBoxMinY, excludeBBoxMaxY;

static int   dissolveBBoxActive = 0;
static float dissolveBBoxMinX, dissolveBBoxMaxX, dissolveBBoxMinY, dissolveBBoxMaxY;

static int   materializeBBoxActive = 0;
static float materializeBBoxMinX, materializeBBoxMaxX, materializeBBoxMinY, materializeBBoxMaxY;

/* Opt 5: Fast sine for wavePhase in [-PI, PI] (Bhaskara-style). */
static inline float fast_sinf(float x) {
    if (x > PI_F) x -= 2.0f * PI_F;
    else if (x < -PI_F) x += 2.0f * PI_F;
    float ax = fabsf(x);
    float parab = x * (PI_F - ax);
    return (4.0f * parab) / (5.0f * PI_F * PI_F - 4.0f * (PI_F - ax) * ax);
}

static void build_frame_ripples(uint32_t currentTime) {
    frameRippleCount = rippleCount;
    /* Post-profile opt: compute union AABB of all valid ripples so the per-dash
       loop can cheaply reject dashes that aren't near any wavefront. */
    float unionMinX = 1e9f, unionMaxX = -1e9f;
    float unionMinY = 1e9f, unionMaxY = -1e9f;
    int anyValid = 0;
    for (int i = 0; i < rippleCount; i++) {
        GridRipple* r = &ripples[i];
        RippleFrame* f = &frameRipples[i];
        f->x = r->x;
        f->y = r->y;
        f->strength = r->strength;
        f->maxDistance = r->maxDistance;
        f->inward = r->inward;
        f->elapsed = (float)(currentTime - r->startTime) / 1000.0f;
        f->valid = 1;

        if (r->inward) {
            f->waveFront = r->maxDistance - f->elapsed * WAVE_SPEED;
            if (f->waveFront <= 0.0f) {
                f->valid = 0;
                continue;
            }
            float minR = f->waveFront - WAVE_WIDTH;
            float maxR = f->waveFront + WAVE_WIDTH;
            f->inwardMaxManhattan = maxR * 1.42f;
            f->inwardMinManhattan = minR > 0.0f ? minR * 0.7f : 0.0f;
            float innerBound = f->waveFront - WAVE_WIDTH;
            f->innerBandSq = innerBound > 0.0f ? innerBound * innerBound : 0.0f;
            f->outerBandSq = (f->waveFront + WAVE_WIDTH) * (f->waveFront + WAVE_WIDTH);
        } else {
            f->waveFront = f->elapsed * WAVE_SPEED;
            /* Manhattan gate matches original any_ripple_in_range (no maxDistance check). */
            float maxReach = f->waveFront + WAVE_WIDTH;
            f->maxReachManhattan = maxReach * 1.42f;
            if (f->waveFront > r->maxDistance) {
                f->valid = 0;
                continue;
            }
            float innerBound = f->waveFront - WAVE_WIDTH;
            f->innerBandSq = innerBound > 0.0f ? innerBound * innerBound : 0.0f;
            f->outerBandSq = (f->waveFront + WAVE_WIDTH) * (f->waveFront + WAVE_WIDTH);
        }

        /* Extend the union box by this ripple's outer reach. */
        float reach = (f->waveFront + WAVE_WIDTH);
        if (reach < 0.0f) reach = 0.0f;
        float lx = f->x - reach, rx = f->x + reach;
        float ly = f->y - reach, ry = f->y + reach;
        if (lx < unionMinX) unionMinX = lx;
        if (rx > unionMaxX) unionMaxX = rx;
        if (ly < unionMinY) unionMinY = ly;
        if (ry > unionMaxY) unionMaxY = ry;
        anyValid = 1;
    }

    if (anyValid) {
        ripplesBBoxActive = 1;
        ripplesBBoxMinX = unionMinX;
        ripplesBBoxMaxX = unionMaxX;
        ripplesBBoxMinY = unionMinY;
        ripplesBBoxMaxY = unionMaxY;
    } else {
        ripplesBBoxActive = 0;
    }
}

static void sort_dedup(int* arr, int* count) {
    int n = *count;
    for (int i = 1; i < n; i++) {
        int key = arr[i];
        int j = i - 1;
        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = key;
    }
    if (n <= 1) return;
    int w = 1;
    for (int r = 1; r < n; r++) {
        if (arr[r] != arr[w - 1])
            arr[w++] = arr[r];
    }
    *count = w;
}

void grid_ripple_set_exclude_zone(float cx, float cy, float radius) {
    if (radius <= 0.0f) {
        excludeZoneActive = 0;
        return;
    }
    excludeZoneActive = 1;
    excludeCx = cx;
    excludeCy = cy;
    excludeRadiusSq = radius * radius;
}

void grid_ripple_init(PlaydateAPI* playdate) {
    pd = playdate;
    rippleCount = 0;
    excludeZoneActive = 0;

    gridXCount = 0;
    int cx = SCREEN_W / 2;
    for (int x = cx; x <= SCREEN_W; x += GRID_SIZE)
        gridX[gridXCount++] = x;
    for (int x = cx - GRID_SIZE; x >= 0; x -= GRID_SIZE)
        gridX[gridXCount++] = x;
    if (gridXCount == 0 || gridX[0] != 0) gridX[gridXCount++] = 0;
    gridX[gridXCount++] = SCREEN_W;
    sort_dedup(gridX, &gridXCount);

    gridYCount = 0;
    int cy = SCREEN_H / 2;
    for (int y = cy; y <= SCREEN_H; y += GRID_SIZE)
        gridY[gridYCount++] = y;
    for (int y = cy - GRID_SIZE; y >= 0; y -= GRID_SIZE)
        gridY[gridYCount++] = y;
    if (gridYCount == 0 || gridY[0] != 0) gridY[gridYCount++] = 0;
    gridY[gridYCount++] = SCREEN_H;
    sort_dedup(gridY, &gridYCount);

    /* Bake integer dash positions for the V (vertical-grid-line) and H
       (horizontal-grid-line) passes once, using the same spacing math the
       per-frame draw used to do. */
    dashesVCount = 0;
    for (int xi = 0; xi < gridXCount; xi++) {
        int gx = gridX[xi];
        for (int yi = 0; yi < gridYCount - 1; yi++) {
            int yS = gridY[yi], yE = gridY[yi + 1];
            int seg = yE - yS;
            if (seg <= 0) continue;
            float spacing = (float)seg / (float)(DASHES_PER_SEGMENT + 1);
            for (int j = 1; j <= DASHES_PER_SEGMENT; j++) {
                int dy = (int)(yS + j * spacing + 0.5f);
                if (dashesVCount < MAX_DASHES_PER_AXIS) {
                    dashesV[dashesVCount].x = (int16_t)gx;
                    dashesV[dashesVCount].y = (int16_t)dy;
                    dashesVCount++;
                }
            }
        }
    }

    dashesHCount = 0;
    for (int yi = 0; yi < gridYCount; yi++) {
        int gy = gridY[yi];
        for (int xi = 0; xi < gridXCount - 1; xi++) {
            int xS = gridX[xi], xE = gridX[xi + 1];
            int seg = xE - xS;
            if (seg <= 0) continue;
            float spacing = (float)seg / (float)(DASHES_PER_SEGMENT + 1);
            for (int j = 1; j <= DASHES_PER_SEGMENT; j++) {
                int dx = (int)(xS + j * spacing + 0.5f);
                if (dashesHCount < MAX_DASHES_PER_AXIS) {
                    dashesH[dashesHCount].x = (int16_t)dx;
                    dashesH[dashesHCount].y = (int16_t)gy;
                    dashesHCount++;
                }
            }
        }
    }
}

static void evict_oldest_ripple_if_full(void) {
    if (rippleCount < ACTIVE_RIPPLE_CAP) return;

    /* Find oldest by startTime. */
    int oldestIdx = 0;
    uint32_t oldestTime = ripples[0].startTime;
    for (int i = 1; i < rippleCount; i++) {
        /* Use signed difference to handle uint32_t wraparound: a "smaller"
           startTime means the ripple started earlier. */
        if ((int32_t)(ripples[i].startTime - oldestTime) < 0) {
            oldestTime = ripples[i].startTime;
            oldestIdx = i;
        }
    }

    /* Compact: shift everything after oldestIdx down by one. */
    if (oldestIdx < rippleCount - 1) {
        memmove(&ripples[oldestIdx],
                &ripples[oldestIdx + 1],
                sizeof(GridRipple) * (rippleCount - oldestIdx - 1));
    }
    rippleCount--;
}

void grid_ripple_add(float x, float y, float strength, float maxAge, uint32_t currentTime) {
    evict_oldest_ripple_if_full();
    GridRipple* r = &ripples[rippleCount++];
    r->x = x;
    r->y = y;
    r->startTime = currentTime; /* same clock as Lua getCachedTime / draw+update */
    r->strength = strength;
    r->maxAge = maxAge;
    r->maxDistance = (maxAge / 1000.0f) * WAVE_SPEED;
    r->inward = 0;
}

void grid_ripple_add_inward(float x, float y, float strength, float startRadius, float maxAge, uint32_t currentTime) {
    evict_oldest_ripple_if_full();
    GridRipple* r = &ripples[rippleCount++];
    r->x = x;
    r->y = y;
    r->startTime = currentTime;
    r->strength = strength;
    r->maxAge = maxAge;
    r->maxDistance = startRadius;
    r->inward = 1;
}

void grid_ripple_update(uint32_t currentTime) {
    int w = 0;
    for (int i = 0; i < rippleCount; i++) {
        GridRipple* r = &ripples[i];
        uint32_t age = currentTime - r->startTime;
        float cap = r->maxAge < (float)MAX_AGE_SAFETY ? r->maxAge : (float)MAX_AGE_SAFETY;
        int keep = 0;

        if (r->inward) {
            float waveFront = r->maxDistance - ((float)age / 1000.0f) * WAVE_SPEED;
            if ((float)age < cap && waveFront > 0.0f)
                keep = 1;
        } else {
            float waveFront = ((float)age / 1000.0f) * WAVE_SPEED;
            if ((float)age < cap && waveFront < r->maxDistance)
                keep = 1;
        }

        if (keep) {
            if (w != i) ripples[w] = ripples[i];
            w++;
        }
    }
    rippleCount = w;
}

/* Post-profile opt D: Accumulate one ripple's contribution into all dashes of
   a single axis. This replaces the old per-dash inner loop over all ripples.
   Each (ripple, dash) pair now pays one AABB gate plus the real math if it
   passes — no duplicate manhattan gate, and no redundant second pass.

   Visual semantics are preserved exactly:
     - offsets (oX, oY) across multiple ripples SUM,
     - wave intensity across multiple ripples takes the MAX.
*/
static void accumulate_ripple_axis(const RippleFrame* r,
                                   const DashPos* dashes, int dashCount,
                                   float* accOX, float* accOY,
                                   float* accIntensity, uint32_t* touchGen) {
    if (!r->valid) return;

    /* Outer AABB of the ripple's outer band (waveFront + WAVE_WIDTH). */
    float reach   = sqrtf(r->outerBandSq);
    float bboxMinX = r->x - reach;
    float bboxMaxX = r->x + reach;
    float bboxMinY = r->y - reach;
    float bboxMaxY = r->y + reach;

    float waveFront = r->waveFront;
    float distRemaining = r->inward ? waveFront : (r->maxDistance - waveFront);
    float fadeStart = WAVE_WIDTH * 2.0f;
    float fadeFactor = distRemaining < fadeStart ? distRemaining / fadeStart : 1.0f;

    for (int i = 0; i < dashCount; i++) {
        float px = (float)dashes[i].x;
        float py = (float)dashes[i].y;

        /* AABB gate replaces the old manhattan pre-pass. */
        if (px < bboxMinX || px > bboxMaxX || py < bboxMinY || py > bboxMaxY)
            continue;

        float dx = px - r->x;
        float dy = py - r->y;
        float distSq = dx * dx + dy * dy;

        if (distSq > r->outerBandSq) continue;
        if (r->innerBandSq > 0.0f && distSq < r->innerBandSq) continue;

        float distance = sqrtf(distSq);
        float distFromWave = fabsf(distance - waveFront);
        if (distFromWave >= WAVE_WIDTH) continue;

        float waveIntensity = (1.0f - distFromWave / WAVE_WIDTH) * fadeFactor;
        float wavePhase = ((distance - waveFront) / WAVE_WIDTH) * PI_F;
        float displacement = fast_sinf(wavePhase) * AMPLITUDE * r->strength * waveIntensity;

        float oX, oY;
        if (distance > 0.001f) {
            float scale = displacement / distance;
            oX = dx * scale;
            oY = dy * scale;
        } else {
            oX = displacement;
            oY = 0.0f;
        }

        /* Lazy zero-init for this frame. */
        if (touchGen[i] != currentFrameGen) {
            touchGen[i]      = currentFrameGen;
            accOX[i]         = oX;
            accOY[i]         = oY;
            accIntensity[i]  = waveIntensity;
        } else {
            accOX[i]        += oX;
            accOY[i]        += oY;
            if (waveIntensity > accIntensity[i])
                accIntensity[i] = waveIntensity;
        }
    }
}

void grid_ripple_dissolve(float originX, float originY, float duration, float speed, uint32_t currentTime) {
    dissolveActive = 1;
    dissolveOriginX = originX;
    dissolveOriginY = originY;
    dissolveStartTime = currentTime;
    dissolveDuration = duration;
    dissolveSpeed = speed;
    materializeActive = 0;
}

void grid_ripple_materialize(float originX, float originY, float duration, float startRadius, uint32_t currentTime) {
    materializeActive = 1;
    materializeOriginX = originX;
    materializeOriginY = originY;
    materializeStartTime = currentTime;
    materializeDuration = duration;
    materializeStartRadius = startRadius;
    dissolveActive = 0;
}

void grid_ripple_reset_dissolve(void) {
    dissolveActive = 0;
    materializeActive = 0;
}

static inline uint32_t dot_hash_float(float fx, float fy, uint32_t ct) {
    int ix = (int)fx;
    int iy = (int)fy;
    return (uint32_t)(ix * 7919 + iy * 104729 + (int)(ct / 100));
}

/* Opt 6: Squared radii; sqrtf only in the narrow edge ring. */
static inline int should_skip_dot(float fx, float fy, uint32_t currentTime) {
    if (dissolveActiveThisFrame) {
        float ddx = fx - dissolveOriginX;
        float ddy = fy - dissolveOriginY;
        float distSq = ddx * ddx + ddy * ddy;
        float edgeZone = DISSOLVE_EDGE_ZONE;
        if (distSq < dissolveRadiusSq) {
            return 1;
        }
        if (distSq < dissolveOuterRadiusSq) {
            float dist = sqrtf(distSq);
            float fadeChance = 1.0f - (dist - dissolveRadiusCached) / edgeZone;
            uint32_t hash = dot_hash_float(fx, fy, currentTime);
            float rand01 = (float)(hash & 0xFF) / 255.0f;
            if (rand01 < fadeChance) {
                return 1;
            }
        }
    }
    if (materializeActiveThisFrame) {
        float ddx = fx - materializeOriginX;
        float ddy = fy - materializeOriginY;
        float distSq = ddx * ddx + ddy * ddy;
        float currentRadius = materializeRadiusCached;
        float edgeZone = DISSOLVE_EDGE_ZONE;
        if (distSq < materializeRadiusSq) {
            return 1;
        }
        if (distSq < materializeOuterRadiusSq) {
            float dist = sqrtf(distSq);
            float fadeChance = (currentRadius + edgeZone - dist) / edgeZone;
            uint32_t hash = dot_hash_float(fx, fy, currentTime);
            float rand01 = (float)(hash & 0xFF) / 255.0f;
            if (rand01 < fadeChance) {
                return 1;
            }
        }
    }
    return 0;
}

/* Opt 7: DASH_LENGTH==1 — single centered sample (same for H/V dashes). */
static inline int pixel_overlaps_exclude_zone(int px, int py) {
    if (!excludeZoneActive) return 0;
    float dx = ((float)px + 0.5f) - excludeCx;
    float dy = ((float)py + 0.5f) - excludeCy;
    return (dx * dx + dy * dy <= excludeRadiusSq) ? 1 : 0;
}

void grid_ripple_draw(int shakeX, int shakeY, uint32_t currentTime) {
    grid_ripple_update(currentTime);

    dissolveActiveThisFrame = 0;
    materializeActiveThisFrame = 0;
    dissolveBBoxActive = 0;
    materializeBBoxActive = 0;

    if (dissolveActive) {
        float elapsed = (float)(currentTime - dissolveStartTime) / 1000.0f;
        dissolveRadiusCached = elapsed * dissolveSpeed;
        dissolveActiveThisFrame = 1;
        dissolveRadiusSq = dissolveRadiusCached * dissolveRadiusCached;
        float dissolveOuter = dissolveRadiusCached + DISSOLVE_EDGE_ZONE;
        dissolveOuterRadiusSq = dissolveOuter * dissolveOuter;

        /* Any dash outside this AABB cannot possibly be inside the outer fade
           zone — skip the per-dash circle math entirely. */
        dissolveBBoxActive = 1;
        dissolveBBoxMinX = dissolveOriginX - dissolveOuter;
        dissolveBBoxMaxX = dissolveOriginX + dissolveOuter;
        dissolveBBoxMinY = dissolveOriginY - dissolveOuter;
        dissolveBBoxMaxY = dissolveOriginY + dissolveOuter;
    }

    if (materializeActive) {
        float elapsed = (float)(currentTime - materializeStartTime) / 1000.0f;
        float durSec = materializeDuration / 1000.0f;
        float progress = durSec > 0.0f ? (elapsed / durSec) : 1.0f;
        if (progress >= 1.0f) {
            materializeActive = 0;
        } else {
            materializeRadiusCached = materializeStartRadius * (1.0f - progress);
            materializeActiveThisFrame = 1;
            materializeRadiusSq = materializeRadiusCached * materializeRadiusCached;
            float matOuter = materializeRadiusCached + DISSOLVE_EDGE_ZONE;
            materializeOuterRadiusSq = matOuter * matOuter;

            materializeBBoxActive = 1;
            materializeBBoxMinX = materializeOriginX - matOuter;
            materializeBBoxMaxX = materializeOriginX + matOuter;
            materializeBBoxMinY = materializeOriginY - matOuter;
            materializeBBoxMaxY = materializeOriginY + matOuter;
        }
    }

    /* Build the tight AABB around the (tiny) exclude zone so the per-dash
       circle test is only run on the few dashes actually near it. */
    if (excludeZoneActive) {
        float r = sqrtf(excludeRadiusSq) + 1.0f;
        excludeBBoxActive = 1;
        excludeBBoxMinX = (int)(excludeCx - r);
        excludeBBoxMaxX = (int)(excludeCx + r) + 1;
        excludeBBoxMinY = (int)(excludeCy - r);
        excludeBBoxMaxY = (int)(excludeCy + r) + 1;
    } else {
        excludeBBoxActive = 0;
    }

    build_frame_ripples(currentTime);

    uint8_t* frame = pd->graphics->getFrame();
    if (!frame) return;
    int rowBytes = LCD_ROWSIZE;

    /* Pixel write macro: clear bit = black in framebuffer = visible on inverted display */
    #define PLOT(px, py) do { \
        int _px = (px), _py = (py); \
        if (_px >= 0 && _px < SCREEN_W && _py >= 0 && _py < SCREEN_H) \
            frame[_py * rowBytes + (_px >> 3)] &= (uint8_t)~(1 << (7 - (_px & 7))); \
    } while(0)

    /* Post-profile opt D: Inverted ripple iteration. Bump the generation
       counter once per frame so stale accumulator slots read as "untouched". */
    currentFrameGen++;
    if (ripplesBBoxActive) {
        for (int r = 0; r < frameRippleCount; r++) {
            const RippleFrame* rf = &frameRipples[r];
            if (!rf->valid) continue;
            accumulate_ripple_axis(rf, dashesV, dashesVCount,
                                   dashOffsetXV, dashOffsetYV,
                                   dashIntensityV, dashTouchGenV);
            accumulate_ripple_axis(rf, dashesH, dashesHCount,
                                   dashOffsetXH, dashOffsetYH,
                                   dashIntensityH, dashTouchGenH);
        }
    }

    const int  effectsActive = dissolveActiveThisFrame | materializeActiveThisFrame;
    const int  excludeActive = excludeBBoxActive;

    /* -------- Pass 1: dashes from vertical grid lines (horizontal stripes). -------- */
    for (int i = 0; i < dashesVCount; i++) {
        int px, py;
        float intensity;

        if (dashTouchGenV[i] == currentFrameGen) {
            px = (int)((float)dashesV[i].x + dashOffsetXV[i] + 0.5f) + shakeX;
            py = (int)((float)dashesV[i].y + dashOffsetYV[i] + 0.5f) + shakeY;
            intensity = dashIntensityV[i];
        } else {
            px = dashesV[i].x + shakeX;
            py = dashesV[i].y + shakeY;
            intensity = 0.0f;
        }

        /* Dissolve / materialize only matter inside their own bboxes. */
        if (effectsActive) {
            if (dissolveActiveThisFrame &&
                (float)px >= dissolveBBoxMinX && (float)px <= dissolveBBoxMaxX &&
                (float)py >= dissolveBBoxMinY && (float)py <= dissolveBBoxMaxY) {
                if (should_skip_dot((float)px, (float)py, currentTime)) continue;
            } else if (materializeActiveThisFrame &&
                (float)px >= materializeBBoxMinX && (float)px <= materializeBBoxMaxX &&
                (float)py >= materializeBBoxMinY && (float)py <= materializeBBoxMaxY) {
                if (should_skip_dot((float)px, (float)py, currentTime)) continue;
            }
        }

        /* The exclude zone is only 14px — skip the float distance check for
           the 99% of dashes that aren't even near it. */
        if (excludeActive &&
            px >= excludeBBoxMinX && px <= excludeBBoxMaxX &&
            py >= excludeBBoxMinY && py <= excludeBBoxMaxY) {
            if (pixel_overlaps_exclude_zone(px, py)) continue;
        }

        if (intensity <= RIPPLE_INTENSITY_LOW) {
            PLOT(px, py);
        } else if (intensity <= RIPPLE_INTENSITY_HIGH) {
            PLOT(px, py);
            PLOT(px + 1, py);
        } else {
            PLOT(px, py);
            PLOT(px + 1, py);
            PLOT(px, py + 1);
            PLOT(px + 1, py + 1);
        }
    }

    /* -------- Pass 2: dashes from horizontal grid lines (vertical stripes). -------- */
    for (int i = 0; i < dashesHCount; i++) {
        int px, py;
        float intensity;

        if (dashTouchGenH[i] == currentFrameGen) {
            px = (int)((float)dashesH[i].x + dashOffsetXH[i] + 0.5f) + shakeX;
            py = (int)((float)dashesH[i].y + dashOffsetYH[i] + 0.5f) + shakeY;
            intensity = dashIntensityH[i];
        } else {
            px = dashesH[i].x + shakeX;
            py = dashesH[i].y + shakeY;
            intensity = 0.0f;
        }

        if (effectsActive) {
            if (dissolveActiveThisFrame &&
                (float)px >= dissolveBBoxMinX && (float)px <= dissolveBBoxMaxX &&
                (float)py >= dissolveBBoxMinY && (float)py <= dissolveBBoxMaxY) {
                if (should_skip_dot((float)px, (float)py, currentTime)) continue;
            } else if (materializeActiveThisFrame &&
                (float)px >= materializeBBoxMinX && (float)px <= materializeBBoxMaxX &&
                (float)py >= materializeBBoxMinY && (float)py <= materializeBBoxMaxY) {
                if (should_skip_dot((float)px, (float)py, currentTime)) continue;
            }
        }

        if (excludeActive &&
            px >= excludeBBoxMinX && px <= excludeBBoxMaxX &&
            py >= excludeBBoxMinY && py <= excludeBBoxMaxY) {
            if (pixel_overlaps_exclude_zone(px, py)) continue;
        }

        if (intensity <= RIPPLE_INTENSITY_LOW) {
            PLOT(px, py);
        } else if (intensity <= RIPPLE_INTENSITY_HIGH) {
            PLOT(px, py);
            PLOT(px, py + 1);
        } else {
            PLOT(px, py);
            PLOT(px + 1, py);
            PLOT(px, py + 1);
            PLOT(px + 1, py + 1);
        }
    }

    pd->graphics->markUpdatedRows(0, SCREEN_H - 1);

    #undef PLOT
}

void grid_ripple_clear(void) {
    rippleCount = 0;
}

/* ========== Lua-callable wrappers ========== */

int c_grid_ripple_add_lua(lua_State* L) {
    float x        = pd->lua->getArgFloat(1);
    float y        = pd->lua->getArgFloat(2);
    float strength = pd->lua->getArgFloat(3);
    float maxAge   = pd->lua->getArgFloat(4);
    uint32_t ct    = (uint32_t)pd->lua->getArgInt(5);
    grid_ripple_add(x, y, strength, maxAge, ct);
    return 0;
}

int c_grid_ripple_add_inward_lua(lua_State* L) {
    float x           = pd->lua->getArgFloat(1);
    float y           = pd->lua->getArgFloat(2);
    float strength    = pd->lua->getArgFloat(3);
    float startRadius = pd->lua->getArgFloat(4);
    float maxAge      = pd->lua->getArgFloat(5);
    uint32_t ct       = (uint32_t)pd->lua->getArgInt(6);
    grid_ripple_add_inward(x, y, strength, startRadius, maxAge, ct);
    return 0;
}

int c_grid_ripple_set_exclude_zone_lua(lua_State* L) {
    float cx = pd->lua->getArgFloat(1);
    float cy = pd->lua->getArgFloat(2);
    float r = pd->lua->getArgFloat(3);
    grid_ripple_set_exclude_zone(cx, cy, r);
    return 0;
}

int c_grid_ripple_draw_lua(lua_State* L) {
    int shakeX      = pd->lua->getArgInt(1);
    int shakeY      = pd->lua->getArgInt(2);
    uint32_t ct     = (uint32_t)pd->lua->getArgInt(3);
    grid_ripple_draw(shakeX, shakeY, ct);
    return 0;
}

int c_grid_ripple_clear_lua(lua_State* L) {
    grid_ripple_clear();
    return 0;
}

int c_grid_ripple_dissolve_lua(lua_State* L) {
    float originX = pd->lua->getArgFloat(1);
    float originY = pd->lua->getArgFloat(2);
    float duration = pd->lua->getArgFloat(3);
    float speed = pd->lua->getArgFloat(4);
    uint32_t ct = (uint32_t)pd->lua->getArgInt(5);
    grid_ripple_dissolve(originX, originY, duration, speed, ct);
    return 0;
}

int c_grid_ripple_reset_dissolve_lua(lua_State* L) {
    (void)L;
    grid_ripple_reset_dissolve();
    return 0;
}

int c_grid_ripple_materialize_lua(lua_State* L) {
    float originX = pd->lua->getArgFloat(1);
    float originY = pd->lua->getArgFloat(2);
    float duration = pd->lua->getArgFloat(3);
    float startRadius = pd->lua->getArgFloat(4);
    uint32_t ct = (uint32_t)pd->lua->getArgInt(5);
    grid_ripple_materialize(originX, originY, duration, startRadius, ct);
    return 0;
}