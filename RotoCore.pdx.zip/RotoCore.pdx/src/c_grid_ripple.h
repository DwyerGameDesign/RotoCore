#ifndef C_GRID_RIPPLE_H
#define C_GRID_RIPPLE_H

#include "pd_api.h"
#include <stdint.h>

#define MAX_RIPPLES 16

typedef struct {
    float x, y;
    uint32_t startTime;
    float strength;
    float maxAge;
    float maxDistance;
    int inward; /* 0 = outward (default), 1 = inward (contracts toward origin) */
} GridRipple;

void grid_ripple_init(PlaydateAPI* playdate);
void grid_ripple_add(float x, float y, float strength, float maxAge, uint32_t currentTime);
void grid_ripple_add_inward(float x, float y, float strength, float startRadius, float maxAge, uint32_t currentTime);
void grid_ripple_update(uint32_t currentTime);
void grid_ripple_set_exclude_zone(float cx, float cy, float radius);
void grid_ripple_draw(int shakeX, int shakeY, uint32_t currentTime);
void grid_ripple_clear(void);

void grid_ripple_dissolve(float originX, float originY, float duration, float speed, uint32_t currentTime);
void grid_ripple_materialize(float originX, float originY, float duration, float startRadius, uint32_t currentTime);
void grid_ripple_reset_dissolve(void);

int c_grid_ripple_add_lua(lua_State* L);
int c_grid_ripple_add_inward_lua(lua_State* L);
int c_grid_ripple_set_exclude_zone_lua(lua_State* L);
int c_grid_ripple_draw_lua(lua_State* L);
int c_grid_ripple_clear_lua(lua_State* L);
int c_grid_ripple_dissolve_lua(lua_State* L);
int c_grid_ripple_reset_dissolve_lua(lua_State* L);
int c_grid_ripple_materialize_lua(lua_State* L);

#endif