#ifndef C_COLLISION_H
#define C_COLLISION_H

#include "pd_api.h"
#include <stdint.h>

#define LASER_RANGE 400.0f
#define IMPACT_SLOWDOWN_VALUE    0.4f
#define IMPACT_SLOWDOWN_DURATION 200

#define SCREEN_WIDTH  400
#define SCREEN_HEIGHT 240

void collision_init(PlaydateAPI* playdate);

void collision_check_all(float playerX, float playerY, float playerRotation,
                         float playerSize, float damage,
                         float startWidth, float endWidth,
                         int hasReverseLaser, float reverseDamage,
                         float reverseStartWidth, float reverseEndWidth,
                         float laserRange,
                         uint32_t currentTime, int deathAnimActive,
                         float pulseKnockbackPx);

void collision_apply_pulse_radial_nudge(float originX, float originY,
                                        float radius, float pushPx,
                                        uint32_t currentTime);

float collision_check_core(float coreX, float coreY, float coreRadius);

int collision_check_enemy_core(void);

/* Radial blast damage with per-enemy wave id on Enemy struct (matches Lua hitEnemies). */
void collision_apply_wave_damage(float x, float y, float radius,
                                 float damage, uint32_t waveId,
                                 uint32_t currentTime);

/* Lua-callable wrappers */
int c_collision_check_all_lua(lua_State* L);
int c_collision_check_core_lua(lua_State* L);
int c_collision_check_enemy_core_lua(lua_State* L);
int c_collision_apply_wave_damage_lua(lua_State* L);
int c_collision_apply_pulse_radial_nudge_lua(lua_State* L);

#endif
