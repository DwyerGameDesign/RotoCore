#include "c_particle.h"
#include <stdlib.h>
#include <math.h>

#define PI_F 3.14159265f

static PlaydateAPI* pd = NULL;
static Particle particles[MAX_PARTICLES];
static int particleCount = 0;

void particle_init(PlaydateAPI* playdate) {
    pd = playdate;
    particleCount = 0;
}

void particle_update(float timeScale) {
    int i = 0;
    while (i < particleCount) {
        Particle* p = &particles[i];
        p->x += p->vx * timeScale;
        p->y += p->vy * timeScale;
        p->life -= 1;

        if (p->life <= 0) {
            particles[i] = particles[--particleCount];
        } else {
            i++;
        }
    }
}

/* Batch-add `count` particles at (x,y) with random angle & speed, scaled by `scale`.
   Returns the number actually added (capped by remaining MAX_PARTICLES capacity). */
int particle_add_burst(float x, float y, int count, float scale, int life) {
    int available = MAX_PARTICLES - particleCount;
    if (available <= 0 || count <= 0) return 0;
    if (count > available) count = available;

    for (int i = 0; i < count; i++) {
        float angle = (float)rand() / (float)RAND_MAX * 2.0f * PI_F;
        float speed = (2.0f + ((float)rand() / (float)RAND_MAX) * 6.0f) * scale;
        Particle* p = &particles[particleCount++];
        p->x = x;
        p->y = y;
        p->vx = cosf(angle) * speed;
        p->vy = sinf(angle) * speed;
        p->life = life;
        p->maxLife = life;
    }
    return count;
}

void particle_clear(void) {
    particleCount = 0;
}

int particle_get_count(void) {
    return particleCount;
}

void particle_draw(PlaydateAPI* playdate) {
    for (int i = 0; i < particleCount; i++) {
        Particle* p = &particles[i];
        int px = (int)(p->x - 1.0f);
        int py = (int)(p->y - 1.0f);
        playdate->graphics->fillRect(px, py, 2, 2, kColorBlack);
    }
}

/* ---------- Lua-callable wrappers ---------- */

int c_particle_update_lua(lua_State* L) {
    float timeScale = pd->lua->getArgFloat(1);
    particle_update(timeScale);
    return 0;
}

int c_particle_add_burst_lua(lua_State* L) {
    float x     = pd->lua->getArgFloat(1);
    float y     = pd->lua->getArgFloat(2);
    int   count = pd->lua->getArgInt(3);
    float scale = pd->lua->getArgFloat(4);
    int   life  = pd->lua->getArgInt(5);

    int added = particle_add_burst(x, y, count, scale, life);
    pd->lua->pushInt(added);
    return 1;
}

int c_particle_clear_lua(lua_State* L) {
    particle_clear();
    return 0;
}

int c_particle_get_count_lua(lua_State* L) {
    pd->lua->pushInt(particleCount);
    return 1;
}

int c_particle_draw_lua(lua_State* L) {
    particle_draw(pd);
    return 0;
}
