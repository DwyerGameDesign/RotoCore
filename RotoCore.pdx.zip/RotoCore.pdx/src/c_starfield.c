#include "c_starfield.h"
#include <math.h>
#include <stdlib.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#define TWO_PI (2.0f * (float)M_PI)

static PlaydateAPI* pd = NULL;

static StarfieldStar stars[STARFIELD_MAX_STARS];
static int starCount = 0;

void starfield_init(PlaydateAPI* playdate) {
    pd = playdate;
    starCount = 0;
}

void starfield_clear(void) {
    starCount = 0;
}

void starfield_populate(int count) {
    if (count < 0) count = 0;
    if (count > STARFIELD_MAX_STARS) count = STARFIELD_MAX_STARS;
    starCount = 0;
    for (int i = 0; i < count; i++) {
        float angle = ((float)rand() / (float)RAND_MAX) * TWO_PI;
        int size = ((float)rand() / (float)RAND_MAX) < 0.3f ? 2 : 1;
        float speed;
        if (size == 2) {
            speed = 0.1f + ((float)rand() / (float)RAND_MAX) * 0.15f;
        } else {
            speed = 0.03f + ((float)rand() / (float)RAND_MAX) * 0.05f;
        }
        stars[starCount].x = (float)(1 + (rand() % STARFIELD_SCREEN_W));
        stars[starCount].y = (float)(1 + (rand() % STARFIELD_SCREEN_H));
        stars[starCount].vx = cosf(angle) * speed;
        stars[starCount].vy = sinf(angle) * speed;
        stars[starCount].size = size;
        starCount++;
    }
}

void starfield_update(int timeDilationActive) {
    if (timeDilationActive) return;
    for (int i = 0; i < starCount; i++) {
        StarfieldStar* s = &stars[i];
        s->x += s->vx;
        s->y += s->vy;
        if (s->x < 0.0f) s->x = (float)STARFIELD_SCREEN_W;
        else if (s->x > (float)STARFIELD_SCREEN_W) s->x = 0.0f;
        if (s->y < 0.0f) s->y = (float)STARFIELD_SCREEN_H;
        else if (s->y > (float)STARFIELD_SCREEN_H) s->y = 0.0f;
    }
}

static inline void plot_black(uint8_t* frame, int rowBytes, int px, int py) {
    if (px >= 0 && px < STARFIELD_SCREEN_W && py >= 0 && py < STARFIELD_SCREEN_H) {
        frame[py * rowBytes + (px >> 3)] &= (uint8_t)~(1 << (7 - (px & 7)));
    }
}

void starfield_draw(int shakeX, int shakeY) {
    if (!pd) return;
    if (starCount == 0) {
        starfield_populate(50);
    }
    uint8_t* frame = pd->graphics->getFrame();
    if (!frame) return;
    int rowBytes = LCD_ROWSIZE;

    for (int i = 0; i < starCount; i++) {
        StarfieldStar* s = &stars[i];
        int x = (int)floorf(s->x + 0.5f) + shakeX;
        int y = (int)floorf(s->y + 0.5f) + shakeY;

        if (s->size == 1) {
            plot_black(frame, rowBytes, x, y);
        } else {
            if (x >= 0 && x < STARFIELD_SCREEN_W && y >= 0 && y < STARFIELD_SCREEN_H) {
                plot_black(frame, rowBytes, x, y);
            }
            if (x >= 1 && x < 399 && y >= 0 && y < STARFIELD_SCREEN_H) {
                plot_black(frame, rowBytes, x - 1, y);
                plot_black(frame, rowBytes, x, y);
                plot_black(frame, rowBytes, x + 1, y);
            }
            if (x >= 0 && x < STARFIELD_SCREEN_W && y >= 1 && y < 239) {
                plot_black(frame, rowBytes, x, y - 1);
                plot_black(frame, rowBytes, x, y);
                plot_black(frame, rowBytes, x, y + 1);
            }
        }
    }

    pd->graphics->markUpdatedRows(0, STARFIELD_SCREEN_H - 1);
}

/* ---------- Lua wrappers ---------- */

int c_starfield_populate_lua(lua_State* L) {
    int count = pd->lua->getArgInt(1);
    starfield_populate(count);
    return 0;
}

int c_starfield_update_lua(lua_State* L) {
    int td = pd->lua->getArgInt(1);
    starfield_update(td);
    return 0;
}

int c_starfield_draw_lua(lua_State* L) {
    int sx = pd->lua->getArgInt(1);
    int sy = pd->lua->getArgInt(2);
    starfield_draw(sx, sy);
    return 0;
}

int c_starfield_clear_lua(lua_State* L) {
    (void)L;
    starfield_clear();
    return 0;
}
