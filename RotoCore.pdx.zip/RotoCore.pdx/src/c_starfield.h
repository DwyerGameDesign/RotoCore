#ifndef C_STARFIELD_H
#define C_STARFIELD_H

#include "pd_api.h"
#include <stdint.h>

#define STARFIELD_MAX_STARS 64
#define STARFIELD_SCREEN_W 400
#define STARFIELD_SCREEN_H 240

typedef struct {
    float x, y, vx, vy;
    int size; /* 1 or 2 */
} StarfieldStar;

void starfield_init(PlaydateAPI* playdate);
void starfield_populate(int count);
void starfield_update(int timeDilationActive);
void starfield_draw(int shakeX, int shakeY);
void starfield_clear(void);

int c_starfield_populate_lua(lua_State* L);
int c_starfield_update_lua(lua_State* L);
int c_starfield_draw_lua(lua_State* L);
int c_starfield_clear_lua(lua_State* L);

#endif
