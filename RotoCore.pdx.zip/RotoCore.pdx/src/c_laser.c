#include "c_laser.h"
#include <math.h>
#include <stdint.h>
#include <stddef.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

static PlaydateAPI* pd = NULL;

/* Classic 8x8 Bayer matrix (matches Playdate kDitherTypeBayer8x8 ordering) */
static const uint8_t kBayer8[8][8] = {
    { 0, 32, 8, 40, 2, 34, 10, 42 },
    { 48, 16, 56, 24, 50, 18, 58, 26 },
    { 12, 44, 4, 36, 14, 46, 6, 38 },
    { 60, 28, 52, 20, 62, 30, 54, 22 },
    { 3, 35, 11, 43, 1, 33, 9, 41 },
    { 51, 19, 59, 27, 49, 17, 57, 25 },
    { 15, 47, 7, 39, 13, 45, 5, 37 },
    { 63, 31, 55, 23, 61, 29, 53, 21 }
};

static const float CHEVRON_LX[5] = { 0.0f, 0.8f, 0.25f, -0.25f, -0.8f };
static const float CHEVRON_LY[5] = { 1.0f, -0.5f, -0.15f, -0.15f, -0.5f };

void laser_init(PlaydateAPI* playdate) {
    pd = playdate;
}

static inline int iround(float f) {
    return (int)floorf(f + 0.5f);
}

/* Lua-style a % b for b > 0: result in [0, b) */
static float fmod_lua_pos(float a, float b) {
    float m = fmodf(a, b);
    if (m < 0.0f) m += b;
    return m;
}

/* Matches Lua setDitherPattern(percent/100) with drawing color black: alpha is ink density
 * (0 = no ink, 1 = solid black). Bit 1 = draw in current color (black). */
static void build_dither_pattern_from_percent(float ditherPercent, LCDPattern out) {
    float alpha = ditherPercent * 0.01f;
    if (alpha < 0.0f) alpha = 0.0f;
    if (alpha > 1.0f) alpha = 1.0f;
    for (int row = 0; row < 8; row++) {
        uint8_t byte = 0;
        for (int col = 0; col < 8; col++) {
            float t = ((float)kBayer8[row][col] + 0.5f) / 64.0f;
            if (t < alpha) {
                byte |= (uint8_t)(1 << (7 - col));
            }
        }
        out[row] = byte;
        out[row + 8] = 0xff;
    }
}

static void transform_point(float playerX, float playerY, float cosR, float sinR, float lx, float ly, float* wx, float* wy) {
    *wx = playerX + (lx * cosR - ly * sinR);
    *wy = playerY + (lx * sinR + ly * cosR);
}

static float get_laser_width_at_y(float y, float tipOffset, float laserLength, float startW, float endW) {
    float progress = (y - tipOffset) / laserLength;
    return startW + (endW - startW) * progress;
}

static void fill_chevron_world(float x, float y, float s, float cosR, float sinR, int* out10) {
    for (int i = 0; i < 5; i++) {
        float lx = CHEVRON_LX[i] * s;
        float ly = CHEVRON_LY[i] * s;
        out10[i * 2] = iround(x + lx * cosR - ly * sinR);
        out10[i * 2 + 1] = iround(y + lx * sinR + ly * cosR);
    }
}

static void draw_closed_polygon_outline(int* xy, int n, int lineWidth, LCDColor color) {
    for (int i = 0; i < n; i++) {
        int j = (i + 1) % n;
        pd->graphics->drawLine(xy[i * 2], xy[i * 2 + 1], xy[j * 2], xy[j * 2 + 1], lineWidth, color);
    }
}

static void fill_trapezoid_dither(float playerX, float playerY, float cosR, float sinR,
    float tipOffset, float laserLength, float startWidth, float endWidth, LCDPattern pat) {
    float x0, y0, x1, y1, x2, y2, x3, y3;
    transform_point(playerX, playerY, cosR, sinR, -startWidth * 0.5f, tipOffset, &x0, &y0);
    transform_point(playerX, playerY, cosR, sinR, startWidth * 0.5f, tipOffset, &x1, &y1);
    transform_point(playerX, playerY, cosR, sinR, endWidth * 0.5f, tipOffset + laserLength, &x2, &y2);
    transform_point(playerX, playerY, cosR, sinR, -endWidth * 0.5f, tipOffset + laserLength, &x3, &y3);
    int coords[8] = {
        iround(x0), iround(y0), iround(x1), iround(y1),
        iround(x2), iround(y2), iround(x3), iround(y3)
    };
    LCDColor c = (LCDColor)(uintptr_t)pat;
    pd->graphics->fillPolygon(4, coords, c, kPolygonFillNonZero);
}

void laser_draw(
    float playerX, float playerY, float rotation, float playerSize,
    float tipOffset, float laserLength, float startWidth, float endWidth,
    float damageMultiplier, int poweredUpLaser, uint32_t currentTime,
    int reverseLaserActive, float reverseStartWidth, float reverseEndWidth,
    float reverseDamageMultiplier, float reverseTipOffset,
    float ditherPercent, float reverseDitherPercent)
{
    if (!pd) return;

    float cosR = cosf(rotation);
    float sinR = sinf(rotation);
    float animationSpeed = 8.0f;
    /* Match Lua: currentTime / (1000/30) * speed */
    float timeScale = (float)currentTime * (30.0f / 1000.0f);

    LCDPattern ditherPat;
    build_dither_pattern_from_percent(ditherPercent, ditherPat);
    fill_trapezoid_dither(playerX, playerY, cosR, sinR, tipOffset, laserLength, startWidth, endWidth, ditherPat);
    /* Lua resets setColor(kColorBlack) after dither; each drawLine below passes kColorBlack. */

    if (poweredUpLaser) {
        int lineSpacing = 12;
        float lineSpeed = animationSpeed * 0.6f * damageMultiplier;
        float lineOffset = fmod_lua_pos(timeScale * lineSpeed, (float)(lineSpacing * 2));

        for (int i = -lineSpacing * 2; i <= (int)laserLength + lineSpacing * 2; i += lineSpacing * 2) {
            float localY = tipOffset + (float)i + lineOffset;
            if (localY >= tipOffset && localY <= tipOffset + laserLength) {
                float widthAtY = get_laser_width_at_y(localY, tipOffset, laserLength, startWidth, endWidth);
                float x1, y1, x2, y2;
                transform_point(playerX, playerY, cosR, sinR, -widthAtY * 0.5f, localY, &x1, &y1);
                transform_point(playerX, playerY, cosR, sinR, widthAtY * 0.5f, localY, &x2, &y2);
                pd->graphics->drawLine(iround(x1), iround(y1), iround(x2), iround(y2), 2, kColorBlack);
            }
        }

        int diagonalSpacing = 20;
        float diagSpeed = animationSpeed * 0.5f * damageMultiplier;
        float diagonalOffset = fmod_lua_pos(timeScale * diagSpeed, (float)(diagonalSpacing * 2));

        for (int i = -diagonalSpacing * 2; i <= (int)laserLength + diagonalSpacing * 2; i += diagonalSpacing * 2) {
            float localY = tipOffset + (float)i + diagonalOffset;
            if (localY >= tipOffset && localY <= tipOffset + laserLength) {
                float widthAtY = get_laser_width_at_y(localY, tipOffset, laserLength, startWidth, endWidth);
                float x1, y1, x2, y2;
                transform_point(playerX, playerY, cosR, sinR, -widthAtY * 0.5f, localY, &x1, &y1);
                transform_point(playerX, playerY, cosR, sinR, widthAtY * 0.5f, localY + diagonalSpacing * 0.5f, &x2, &y2);
                pd->graphics->drawLine(iround(x1), iround(y1), iround(x2), iround(y2), 1, kColorBlack);
            }
        }
    } else {
        int lineSpacing = 16;
        float lineSpeed = animationSpeed * 0.4f * damageMultiplier;
        float lineOffset = fmod_lua_pos(timeScale * lineSpeed, (float)(lineSpacing * 2));

        for (int i = -lineSpacing * 2; i <= (int)laserLength + lineSpacing * 2; i += lineSpacing * 2) {
            float localY = tipOffset + (float)i + lineOffset;
            if (localY >= tipOffset && localY <= tipOffset + laserLength) {
                float widthAtY = get_laser_width_at_y(localY, tipOffset, laserLength, startWidth, endWidth);
                float x1, y1, x2, y2;
                transform_point(playerX, playerY, cosR, sinR, -widthAtY * 0.5f, localY, &x1, &y1);
                transform_point(playerX, playerY, cosR, sinR, widthAtY * 0.5f, localY, &x2, &y2);
                pd->graphics->drawLine(iround(x1), iround(y1), iround(x2), iround(y2), 2, kColorBlack);
            }
        }

        int streakSpacing = 24;
        float streakSpeed = animationSpeed * 0.7f * damageMultiplier;
        float streakOffset = fmod_lua_pos(timeScale * streakSpeed, (float)(streakSpacing * 2));

        for (int i = -streakSpacing * 2; i <= (int)laserLength + streakSpacing * 2; i += streakSpacing * 2) {
            float localY = tipOffset + (float)i + streakOffset;
            if (localY >= tipOffset && localY <= tipOffset + laserLength) {
                float widthAtY = get_laser_width_at_y(localY, tipOffset, laserLength, startWidth, endWidth);
                float streakLength = widthAtY * 0.3f;
                float x1, y1, x2, y2, x3, y3, x4, y4;
                transform_point(playerX, playerY, cosR, sinR, -widthAtY * 0.5f + streakLength, localY, &x1, &y1);
                transform_point(playerX, playerY, cosR, sinR, -widthAtY * 0.5f, localY + streakLength, &x2, &y2);
                pd->graphics->drawLine(iround(x1), iround(y1), iround(x2), iround(y2), 1, kColorBlack);
                transform_point(playerX, playerY, cosR, sinR, widthAtY * 0.5f - streakLength, localY, &x3, &y3);
                transform_point(playerX, playerY, cosR, sinR, widthAtY * 0.5f, localY + streakLength, &x4, &y4);
                pd->graphics->drawLine(iround(x3), iround(y3), iround(x4), iround(y4), 1, kColorBlack);
            }
        }
    }

    if (reverseLaserActive) {
        float revRot = rotation + (float)M_PI;
        float rcos = cosf(revRot);
        float rsin = sinf(revRot);

        LCDPattern revPat;
        build_dither_pattern_from_percent(reverseDitherPercent, revPat);
        fill_trapezoid_dither(playerX, playerY, rcos, rsin, reverseTipOffset, laserLength,
            reverseStartWidth, reverseEndWidth, revPat);
        /* Lua: setColor(kColorBlack); lines use explicit kColorBlack. */

        int reverseLineSpacing = 16;
        float reverseLineSpeed = animationSpeed * 0.4f * reverseDamageMultiplier;
        float reverseLineOffset = fmod_lua_pos(timeScale * reverseLineSpeed, (float)(reverseLineSpacing * 2));

        for (int i = -reverseLineSpacing * 2; i <= (int)laserLength + reverseLineSpacing * 2; i += reverseLineSpacing * 2) {
            float localY = reverseTipOffset + (float)i + reverseLineOffset;
            if (localY >= reverseTipOffset && localY <= reverseTipOffset + laserLength) {
                float widthAtY = get_laser_width_at_y(localY, reverseTipOffset, laserLength, reverseStartWidth, reverseEndWidth);
                float x1, y1, x2, y2;
                transform_point(playerX, playerY, rcos, rsin, -widthAtY * 0.5f, localY, &x1, &y1);
                transform_point(playerX, playerY, rcos, rsin, widthAtY * 0.5f, localY, &x2, &y2);
                pd->graphics->drawLine(iround(x1), iround(y1), iround(x2), iround(y2), 2, kColorBlack);
            }
        }

        int reverseStreakSpacing = 24;
        float reverseStreakSpeed = animationSpeed * 0.7f * reverseDamageMultiplier;
        float reverseStreakOffset = fmod_lua_pos(timeScale * reverseStreakSpeed, (float)(reverseStreakSpacing * 2));

        for (int i = -reverseStreakSpacing * 2; i <= (int)laserLength + reverseStreakSpacing * 2; i += reverseStreakSpacing * 2) {
            float localY = reverseTipOffset + (float)i + reverseStreakOffset;
            if (localY >= reverseTipOffset && localY <= reverseTipOffset + laserLength) {
                float widthAtY = get_laser_width_at_y(localY, reverseTipOffset, laserLength, reverseStartWidth, reverseEndWidth);
                float streakLength = widthAtY * 0.3f;
                float x1, y1, x2, y2, x3, y3, x4, y4;
                transform_point(playerX, playerY, rcos, rsin, -widthAtY * 0.5f + streakLength, localY, &x1, &y1);
                transform_point(playerX, playerY, rcos, rsin, -widthAtY * 0.5f, localY + streakLength, &x2, &y2);
                pd->graphics->drawLine(iround(x1), iround(y1), iround(x2), iround(y2), 1, kColorBlack);
                transform_point(playerX, playerY, rcos, rsin, widthAtY * 0.5f - streakLength, localY, &x3, &y3);
                transform_point(playerX, playerY, rcos, rsin, widthAtY * 0.5f, localY + streakLength, &x4, &y4);
                pd->graphics->drawLine(iround(x3), iround(y3), iround(x4), iround(y4), 1, kColorBlack);
            }
        }
    }

    int chevron[10];
    float cutCos = cosf(rotation);
    float cutSin = sinf(rotation);
    float cutSize = poweredUpLaser ? (playerSize + 5.0f) : playerSize;
    fill_chevron_world(playerX, playerY, cutSize, cutCos, cutSin, chevron);
    pd->graphics->fillPolygon(5, chevron, kColorWhite, kPolygonFillNonZero);

    if (poweredUpLaser) {
        float glowSize = playerSize + 5.0f;
        fill_chevron_world(playerX, playerY, glowSize, cutCos, cutSin, chevron);
        draw_closed_polygon_outline(chevron, 5, 2, kColorBlack);

        fill_chevron_world(playerX, playerY, playerSize, cutCos, cutSin, chevron);
        pd->graphics->fillPolygon(5, chevron, kColorWhite, kPolygonFillNonZero);

        draw_closed_polygon_outline(chevron, 5, 2, kColorBlack);

        int cx = iround(playerX);
        int cy = iround(playerY);
        int r = 3;
        pd->graphics->fillEllipse(cx - r, cy - r, 2 * r, 2 * r, 0.0f, 360.0f, kColorBlack);
    }
}

int c_laser_draw_lua(lua_State* L) {
    (void)L;
    float playerX = pd->lua->getArgFloat(1);
    float playerY = pd->lua->getArgFloat(2);
    float rotation = pd->lua->getArgFloat(3);
    float playerSize = pd->lua->getArgFloat(4);
    float tipOffset = pd->lua->getArgFloat(5);
    float laserLength = pd->lua->getArgFloat(6);
    float startWidth = pd->lua->getArgFloat(7);
    float endWidth = pd->lua->getArgFloat(8);
    float damageMultiplier = pd->lua->getArgFloat(9);
    int poweredUpLaser = pd->lua->getArgInt(10);
    uint32_t currentTime = (uint32_t)pd->lua->getArgInt(11);
    int reverseLaserActive = pd->lua->getArgInt(12);
    float reverseStartWidth = pd->lua->getArgFloat(13);
    float reverseEndWidth = pd->lua->getArgFloat(14);
    float reverseDamageMultiplier = pd->lua->getArgFloat(15);
    float reverseTipOffset = pd->lua->getArgFloat(16);
    float ditherPercent = pd->lua->getArgFloat(17);
    float reverseDitherPercent = pd->lua->getArgFloat(18);

    laser_draw(playerX, playerY, rotation, playerSize, tipOffset, laserLength, startWidth, endWidth,
        damageMultiplier, poweredUpLaser, currentTime, reverseLaserActive,
        reverseStartWidth, reverseEndWidth, reverseDamageMultiplier, reverseTipOffset,
        ditherPercent, reverseDitherPercent);
    return 0;
}
