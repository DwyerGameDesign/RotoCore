#include "c_enemy.h"
#include <math.h>
#include <stddef.h>

#define PI_F    3.14159265f
#define HALF_PI (PI_F * 0.5f)

static PlaydateAPI* pd = NULL;
static Enemy enemies[MAX_ENEMIES];
static int enemyCount = 0;
static uint32_t nextEnemyId = 1;

static HexSpawnInfo hexSpawns[MAX_HEX_SPAWNS];
static int hexSpawnCount = 0;

/* Classic 8x8 Bayer matrix (matches Playdate kDitherTypeBayer8x8 ordering) — same as c_laser.c */
static const uint8_t kEnemyBayer8[8][8] = {
    { 0, 32, 8, 40, 2, 34, 10, 42 },
    { 48, 16, 56, 24, 50, 18, 58, 26 },
    { 12, 44, 4, 36, 14, 46, 6, 38 },
    { 60, 28, 52, 20, 62, 30, 54, 22 },
    { 3, 35, 11, 43, 1, 33, 9, 41 },
    { 51, 19, 59, 27, 49, 17, 57, 25 },
    { 15, 47, 7, 39, 13, 45, 5, 37 },
    { 63, 31, 55, 23, 61, 29, 53, 21 }
};

static LCDPattern kEnemyDither25;
static LCDPattern kEnemyDither50;
static int enemyDitherInitialized = 0;

static inline int iround(float f) {
    return (int)floorf(f + 0.5f);
}

/* Matches visual.setDitherPattern(percent) / Lua setDitherPattern(percent/100) with drawing color black */
static void build_enemy_dither_pattern(float ditherPercent, LCDPattern out) {
    float alpha = ditherPercent * 0.01f;
    if (alpha < 0.0f) alpha = 0.0f;
    if (alpha > 1.0f) alpha = 1.0f;
    for (int row = 0; row < 8; row++) {
        uint8_t byte = 0;
        for (int col = 0; col < 8; col++) {
            float t = ((float)kEnemyBayer8[row][col] + 0.5f) / 64.0f;
            if (t < alpha) {
                byte |= (uint8_t)(1 << (7 - col));
            }
        }
        out[row] = byte;
        out[row + 8] = 0xff;
    }
}

static void ensure_enemy_dithers_built(void) {
    if (enemyDitherInitialized) return;
    build_enemy_dither_pattern(25.0f, kEnemyDither25);
    build_enemy_dither_pattern(50.0f, kEnemyDither50);
    enemyDitherInitialized = 1;
}

static inline LCDColor enemy_fill_color_for_style(int bodyFillStyle) {
    if (bodyFillStyle == 25)
        return (LCDColor)(uintptr_t)kEnemyDither25;
    if (bodyFillStyle == 50)
        return (LCDColor)(uintptr_t)kEnemyDither50;
    return kColorBlack;
}

static void draw_closed_polygon_outline_int(const int* coords, int n, int lineWidth, LCDColor color) {
    for (int i = 0; i < n; i++) {
        int j = (i + 1) % n;
        pd->graphics->drawLine(coords[i * 2], coords[i * 2 + 1],
            coords[j * 2], coords[j * 2 + 1], lineWidth, color);
    }
}

static inline void draw_diamond_outline(float x, float y, float radius, float rotation,
    int lineWidth, float scale) {
    float widthRadius = radius * 0.65f * scale;
    float heightRadius = radius * 1.2f * scale;
    float cosR = cosf(rotation);
    float sinR = sinf(rotation);
    int coords[8] = {
        iround(x + (-heightRadius * sinR)), iround(y + (-heightRadius * cosR)),
        iround(x + (widthRadius * cosR)), iround(y + (-widthRadius * sinR)),
        iround(x + (heightRadius * sinR)), iround(y + (heightRadius * cosR)),
        iround(x + (-widthRadius * cosR)), iround(y + (widthRadius * sinR))
    };
    draw_closed_polygon_outline_int(coords, 4, lineWidth, kColorBlack);
}

static inline void draw_diamond_filled(float x, float y, float radius, float rotation,
    float fillRatio, LCDColor fillColor) {
    float widthRadius = radius * 0.65f * fillRatio;
    float heightRadius = radius * 1.2f * fillRatio;
    float cosR = cosf(rotation);
    float sinR = sinf(rotation);
    int coords[8] = {
        iround(x + (-heightRadius * sinR)), iround(y + (-heightRadius * cosR)),
        iround(x + (widthRadius * cosR)), iround(y + (-widthRadius * sinR)),
        iround(x + (heightRadius * sinR)), iround(y + (heightRadius * cosR)),
        iround(x + (-widthRadius * cosR)), iround(y + (widthRadius * sinR))
    };
    pd->graphics->fillPolygon(4, coords, fillColor, kPolygonFillNonZero);
}

static inline void draw_circle_outline(float cx, float cy, float r, int lineWidth) {
    int d = iround(r * 2.0f);
    int x = iround(cx - r);
    int y = iround(cy - r);
    pd->graphics->drawEllipse(x, y, d, d, lineWidth, 0.0f, 0.0f, kColorBlack);
}

static inline void draw_circle_filled(float cx, float cy, float r, LCDColor fillColor) {
    int d = iround(r * 2.0f);
    int x = iround(cx - r);
    int y = iround(cy - r);
    /* Same angle convention as c_laser.c laser chevron hub fill */
    pd->graphics->fillEllipse(x, y, d, d, 0.0f, 360.0f, fillColor);
}

static inline void draw_enemy_polygon_outline(const Enemy* e, int borderWidth) {
    int n = e->vertexCount;
    if (n < 3 || n > 6) return;
    int coords[12];
    for (int v = 0; v < n; v++) {
        coords[v * 2]     = iround(e->vertices[v * 2]);
        coords[v * 2 + 1] = iround(e->vertices[v * 2 + 1]);
    }
    draw_closed_polygon_outline_int(coords, n, borderWidth, kColorBlack);
}

static inline void fill_scaled_polygon(const Enemy* e, float ex, float ey, float fillRatio, LCDColor fillColor) {
    int n = e->vertexCount;
    if (n < 3 || n > 6) return;
    int coords[12];
    for (int v = 0; v < n; v++) {
        float vx = e->vertices[v * 2];
        float vy = e->vertices[v * 2 + 1];
        coords[v * 2]     = iround(ex + (vx - ex) * fillRatio);
        coords[v * 2 + 1] = iround(ey + (vy - ey) * fillRatio);
    }
    pd->graphics->fillPolygon(n, coords, fillColor, kPolygonFillNonZero);
}

static inline void draw_scaled_polygon_outline(const Enemy* e, float ex, float ey,
    float s, int lineWidth) {
    int n = e->vertexCount;
    if (n < 3 || n > 6) return;
    int coords[12];
    for (int v = 0; v < n; v++) {
        float vx = e->vertices[v * 2];
        float vy = e->vertices[v * 2 + 1];
        coords[v * 2]     = iround(ex + (vx - ex) * s);
        coords[v * 2 + 1] = iround(ey + (vy - ey) * s);
    }
    draw_closed_polygon_outline_int(coords, n, lineWidth, kColorBlack);
}

void enemy_draw_all(uint32_t currentTime, int deathEnemyIndex, int screenW, int screenH) {
    if (!pd) return;

    ensure_enemy_dithers_built();

    /* C graphics API has no setColor/setLineWidth — pass LCDColor and width per draw. */

    int flashRate = ((int)(currentTime / 100u)) & 1;

    /* Tracks Lua currentDitherPattern: 0 = none, else 25 or 50 */
    int currentDitherStyle = 0;

    for (int i = 0; i < enemyCount; i++) {
        if (i == deathEnemyIndex)
            continue;

        Enemy* e = &enemies[i];
        if (e->destroyed)
            continue;

        float ex = e->x;
        float ey = e->y;
        float r  = e->radius;

        if (!(ex + r >= 0.0f && ex - r <= (float)screenW &&
              ey + r >= 0.0f && ey - r <= (float)screenH))
            continue;

        float healthPercent = (e->maxHealth > 0.0f) ? (e->health / e->maxHealth) : 0.0f;
        if (healthPercent < 0.0f) healthPercent = 0.0f;
        if (healthPercent > 1.0f) healthPercent = 1.0f;

        int borderWidth = 2;
        if (e->healthMultiplier >= 5.0f)
            borderWidth = 6;
        else if (e->healthMultiplier >= 3.0f)
            borderWidth = 4;
        if (e->hardened)
            borderWidth += 1;

        int isDiamond = (e->typeName == ENEMY_DIAMOND);
        int isCircle  = (e->typeName == ENEMY_CIRCLE);

        int bodyFillStyle = 0;
        if (e->typeName == ENEMY_SQUARE || e->typeName == ENEMY_PENTAGON) {
            bodyFillStyle = 25;
        } else if (e->typeName == ENEMY_HEXAGON) {
            bodyFillStyle = 50;
        } else if (e->hardened && (isDiamond || isCircle)) {
            bodyFillStyle = 25;
        }

        int usesDamageFill =
            (e->typeName == ENEMY_SQUARE ||
             e->typeName == ENEMY_PENTAGON ||
             e->typeName == ENEMY_HEXAGON ||
             (e->hardened && (isDiamond || isCircle))) ? 1 : 0;

        if (currentDitherStyle != 0)
            currentDitherStyle = 0;

        if (isDiamond) {
            draw_diamond_outline(ex, ey, r, e->rotation, borderWidth, 1.0f);
        } else if (isCircle) {
            draw_circle_outline(ex, ey, r, borderWidth);
        } else {
            draw_enemy_polygon_outline(e, borderWidth);
        }

        if (usesDamageFill) {
            float fillRatio = 1.0f - healthPercent;
            if (fillRatio > 0.05f) {
                if (bodyFillStyle > 0 && currentDitherStyle != bodyFillStyle)
                    currentDitherStyle = bodyFillStyle;

                LCDColor fillCol = (bodyFillStyle > 0)
                    ? enemy_fill_color_for_style(bodyFillStyle)
                    : kColorBlack;

                if (isCircle) {
                    float fillRadius = r * fillRatio;
                    draw_circle_filled(ex, ey, fillRadius, fillCol);
                } else if (isDiamond && e->hardened) {
                    draw_diamond_filled(ex, ey, r, e->rotation, fillRatio, fillCol);
                } else if (e->vertexCount >= 4) {
                    fill_scaled_polygon(e, ex, ey, fillRatio, fillCol);
                }
            }
        }

        if (healthPercent < 0.3f && flashRate == 0 && currentDitherStyle != 0)
            currentDitherStyle = 0;

        if (healthPercent < 0.3f && flashRate == 0) {
            if (isDiamond) {
                draw_diamond_outline(ex, ey, r, e->rotation, 1, 0.7f);
            } else if (isCircle) {
                draw_circle_outline(ex, ey, r * 0.7f, 1);
            } else if (e->vertexCount >= 4) {
                draw_scaled_polygon_outline(e, ex, ey, 0.7f, 1);
            }
        }
    }
}

static void compute_vertices(Enemy* e) {
    if (e->sides >= 3 && e->sides <= 6) {
        float baseAngle = -HALF_PI + e->rotation;
        float angleStep = (2.0f * PI_F) / (float)e->sides;
        e->vertexCount = e->sides;
        for (int v = 0; v < e->sides; v++) {
            float angle = angleStep * (float)v + baseAngle;
            e->vertices[v * 2]     = e->x + cosf(angle) * e->radius;
            e->vertices[v * 2 + 1] = e->y + sinf(angle) * e->radius;
        }
    } else {
        e->vertexCount = 0;
    }
}

void enemy_init(PlaydateAPI* playdate) {
    pd = playdate;
    enemyCount = 0;
    hexSpawnCount = 0;
    nextEnemyId = 1;
}

int enemy_update(uint32_t currentTime, float timeScale, int timeDilationActive) {
    hexSpawnCount = 0;

    for (int i = 0; i < enemyCount; i++) {
        Enemy* e = &enemies[i];

        /* --- freeze logic --- */
        if (e->frozen && e->frozenUntil != 0) {
            if (currentTime >= e->frozenUntil) {
                e->frozen = 0;
                e->frozenUntil = 0;
            } else {
                continue;
            }
        }
        if (e->frozen)    continue;
        if (e->destroyed) continue;

        /* --- movement speed --- */
        float moveSpeed = e->speed;
        if (timeDilationActive)
            moveSpeed *= TIME_DILATION_FACTOR;

        if (e->impactSlowdownUntil > currentTime) {
            moveSpeed *= e->impactSlowdown;
        } else {
            e->impactSlowdown = 1.0f;
        }

        /* --- rotation (uses timeScale for death-anim slowdown) --- */
        e->rotation += e->rotationSpeed * timeScale;

        /* --- move toward center --- */
        float dx = CENTER_X - e->x;
        float dy = CENTER_Y - e->y;
        float distSq = dx * dx + dy * dy;

        /* --- pulse knockback step (applied before homing, so homing fights it back) --- */
        if (e->knockbackVx != 0.0f || e->knockbackVy != 0.0f) {
            /* Knockback animation tuning:
               - Decay multiplier (0.5): each frame, velocity is halved. Lower = punchier/shorter, higher = softer/longer.
               - Epsilon (0.05): velocity below this snaps to zero. Avoids float drift; tune with decay together.
               With 0.5 decay and 0.05 epsilon, animation runs ~6-7 frames at 30fps (~200-230ms). */
            e->x += e->knockbackVx;
            e->y += e->knockbackVy;

            if (e->x < 0.0f)             e->x = 0.0f;
            if (e->x > SCREEN_WIDTH)     e->x = (float)SCREEN_WIDTH;
            if (e->y < 0.0f)             e->y = 0.0f;
            if (e->y > SCREEN_HEIGHT)    e->y = (float)SCREEN_HEIGHT;

            e->knockbackVx *= 0.5f;
            e->knockbackVy *= 0.5f;

            if (fabsf(e->knockbackVx) < 0.05f) e->knockbackVx = 0.0f;
            if (fabsf(e->knockbackVy) < 0.05f) e->knockbackVy = 0.0f;
        }

        if (distSq > CENTER_DANGER_RADIUS_SQ) {
            float dist = sqrtf(distSq);
            /* movement does NOT use timeScale (matches HTML behaviour) */
            e->x += (dx / dist) * moveSpeed;
            e->y += (dy / dist) * moveSpeed;

            /* hexagon circle emission */
            if (e->typeName == ENEMY_HEXAGON) {
                if (e->lastSpawnTime == 0)
                    e->lastSpawnTime = currentTime;

                if (currentTime - e->lastSpawnTime >= HEXAGON_SPAWN_INTERVAL) {
                    e->lastSpawnTime = currentTime;

                    if (hexSpawnCount < MAX_HEX_SPAWNS) {
                        HexSpawnInfo* hs = &hexSpawns[hexSpawnCount++];
                        hs->x  = e->x;
                        hs->y  = e->y;
                        hs->dx = dx;
                        hs->dy = dy;
                    }
                }
            }
        }

        /* pre-compute polygon vertices for draw loop */
        compute_vertices(e);
    }
    return hexSpawnCount;
}

int enemy_add(float x, float y, float speed, float rotation, float rotationSpeed,
              float radius, int sides, int typeName, float health, float maxHealth,
              float healthMultiplier, int hardened, int points, uint32_t lastSpawnTime) {
    if (enemyCount >= MAX_ENEMIES) return -1;

    Enemy* e = &enemies[enemyCount];
    e->x = x;
    e->y = y;
    e->speed = speed;
    e->rotation = rotation;
    e->rotationSpeed = rotationSpeed;
    e->impactSlowdown = 1.0f;
    e->impactSlowdownUntil = 0;
    e->knockbackVx = 0.0f;
    e->knockbackVy = 0.0f;
    e->frozenUntil = 0;
    e->radius = radius;
    e->healthMultiplier = healthMultiplier;
    e->health = health;
    e->maxHealth = maxHealth;
    e->sides = sides;
    e->points = points;
    e->lastSpawnTime = lastSpawnTime;
    e->id = nextEnemyId++;
    e->lastHitWaveId = 0;
    e->typeName = (uint8_t)typeName;
    e->frozen = 0;
    e->destroyed = 0;
    e->hardened = (uint8_t)hardened;

    compute_vertices(e);

    return enemyCount++;
}

void enemy_remove(int index) {
    if (index < 0 || index >= enemyCount) return;
    enemies[index] = enemies[--enemyCount];
}

void enemy_clear(void) {
    enemyCount = 0;
    hexSpawnCount = 0;
}

int enemy_get_count(void) {
    return enemyCount;
}

Enemy* enemy_get_ptr(int index) {
    if (index < 0 || index >= enemyCount) return NULL;
    return &enemies[index];
}

void enemy_freeze_all(void) {
    for (int i = 0; i < enemyCount; i++)
        enemies[i].frozen = 1;
}

Enemy* enemy_get_array(int* outCount) {
    if (outCount) *outCount = enemyCount;
    return enemies;
}

const HexSpawnInfo* enemy_get_hex_spawn(int index) {
    if (index < 0 || index >= hexSpawnCount) return NULL;
    return &hexSpawns[index];
}

/* ========== Lua-callable wrappers ========== */

int c_enemy_update_lua(lua_State* L) {
    uint32_t currentTime      = (uint32_t)pd->lua->getArgInt(1);
    float    timeScale         = pd->lua->getArgFloat(2);
    int      timeDilationActive = pd->lua->getArgBool(3);

    int hc = enemy_update(currentTime, timeScale, timeDilationActive);
    pd->lua->pushInt(hc);
    return 1;
}

int c_enemy_add_lua(lua_State* L) {
    float    x               = pd->lua->getArgFloat(1);
    float    y               = pd->lua->getArgFloat(2);
    float    speed           = pd->lua->getArgFloat(3);
    float    rotation        = pd->lua->getArgFloat(4);
    float    rotationSpeed   = pd->lua->getArgFloat(5);
    float    radius          = pd->lua->getArgFloat(6);
    int      sides           = pd->lua->getArgInt(7);
    int      typeName        = pd->lua->getArgInt(8);
    float    health          = pd->lua->getArgFloat(9);
    float    maxHealth       = pd->lua->getArgFloat(10);
    float    healthMultiplier = pd->lua->getArgFloat(11);
    int      hardened        = pd->lua->getArgBool(12);
    int      points          = pd->lua->getArgInt(13);
    uint32_t lastSpawnTime   = (uint32_t)pd->lua->getArgInt(14);

    int idx = enemy_add(x, y, speed, rotation, rotationSpeed, radius, sides,
                        typeName, health, maxHealth, healthMultiplier,
                        hardened, points, lastSpawnTime);
    pd->lua->pushInt(idx);
    return 1;
}

int c_enemy_remove_lua(lua_State* L) {
    int index = pd->lua->getArgInt(1);
    enemy_remove(index);
    return 0;
}

int c_enemy_clear_lua(lua_State* L) {
    enemy_clear();
    return 0;
}

int c_enemy_get_count_lua(lua_State* L) {
    pd->lua->pushInt(enemyCount);
    return 1;
}

/* Returns: x, y, rotation, radius, sides, typeName, health, maxHealth,
            healthMultiplier, hardened, destroyed, points, id */
int c_enemy_get_lua(lua_State* L) {
    int index = pd->lua->getArgInt(1);
    Enemy* e = enemy_get_ptr(index);
    if (!e) {
        pd->lua->pushNil();
        return 1;
    }
    pd->lua->pushFloat(e->x);                /* 1 */
    pd->lua->pushFloat(e->y);                /* 2 */
    pd->lua->pushFloat(e->rotation);         /* 3 */
    pd->lua->pushFloat(e->radius);           /* 4 */
    pd->lua->pushInt(e->sides);              /* 5 */
    pd->lua->pushInt(e->typeName);           /* 6 */
    pd->lua->pushFloat(e->health);            /* 7 */
    pd->lua->pushFloat(e->maxHealth);        /* 8 */
    pd->lua->pushFloat(e->healthMultiplier); /* 9 */
    pd->lua->pushBool(e->hardened);          /* 10 */
    pd->lua->pushBool(e->destroyed);         /* 11 */
    pd->lua->pushInt(e->points);             /* 12 */
    pd->lua->pushInt((int)e->id);            /* 13 */
    return 13;
}

int c_enemy_set_health_lua(lua_State* L) {
    int index = pd->lua->getArgInt(1);
    float health = pd->lua->getArgFloat(2);
    Enemy* e = enemy_get_ptr(index);
    if (e) e->health = health;
    return 0;
}

int c_enemy_set_destroyed_lua(lua_State* L) {
    int index = pd->lua->getArgInt(1);
    int destroyed = pd->lua->getArgBool(2);
    Enemy* e = enemy_get_ptr(index);
    if (e) e->destroyed = (uint8_t)destroyed;
    return 0;
}

int c_enemy_get_hex_spawn_lua(lua_State* L) {
    int index = pd->lua->getArgInt(1);
    const HexSpawnInfo* hs = enemy_get_hex_spawn(index);
    if (!hs) {
        pd->lua->pushNil();
        return 1;
    }
    pd->lua->pushFloat(hs->x);
    pd->lua->pushFloat(hs->y);
    pd->lua->pushFloat(hs->dx);
    pd->lua->pushFloat(hs->dy);
    return 4;
}

int c_enemy_freeze_all_lua(lua_State* L) {
    enemy_freeze_all();
    return 0;
}

void enemy_freeze_all_timed(uint32_t frozenUntil) {
    for (int i = 0; i < enemyCount; i++) {
        enemies[i].frozen = 1;
        enemies[i].frozenUntil = frozenUntil;
    }
}

int c_enemy_freeze_all_timed_lua(lua_State* L) {
    uint32_t frozenUntil = (uint32_t)pd->lua->getArgInt(1);
    enemy_freeze_all_timed(frozenUntil);
    return 0;
}

/* Returns: x, y, radius, sides, typeName, health, maxHealth,
            healthMultiplier, hardened, destroyed, points, id
   12 values — only called for dead enemies */
int c_enemy_get_death_lua(lua_State* L) {
    int index = pd->lua->getArgInt(1);
    Enemy* e = enemy_get_ptr(index);
    if (!e) {
        pd->lua->pushNil();
        return 1;
    }
    pd->lua->pushFloat(e->x);                /* 1 */
    pd->lua->pushFloat(e->y);                /* 2 */
    pd->lua->pushFloat(e->radius);           /* 3 */
    pd->lua->pushInt(e->sides);              /* 4 */
    pd->lua->pushInt(e->typeName);           /* 5 */
    pd->lua->pushFloat(e->health);           /* 6 */
    pd->lua->pushFloat(e->maxHealth);        /* 7 */
    pd->lua->pushFloat(e->healthMultiplier); /* 8 */
    pd->lua->pushBool(e->hardened);          /* 9 */
    pd->lua->pushBool(e->destroyed);         /* 10 */
    pd->lua->pushInt(e->points);             /* 11 */
    pd->lua->pushInt((int)e->id);            /* 12 */
    return 12;
}

/* Returns: health only — fast scan for removeDeadEnemies */
int c_enemy_get_health_lua(lua_State* L) {
    int index = pd->lua->getArgInt(1);
    Enemy* e = enemy_get_ptr(index);
    if (!e) {
        pd->lua->pushNil();
        return 1;
    }
    pd->lua->pushFloat(e->health);
    return 1;
}

int c_enemy_draw_all_lua(lua_State* L) {
    (void)L;
    uint32_t currentTime = (uint32_t)pd->lua->getArgInt(1);
    int      deathIndex  = pd->lua->getArgInt(2);
    int      screenW     = pd->lua->getArgInt(3);
    int      screenH     = pd->lua->getArgInt(4);
    enemy_draw_all(currentTime, deathIndex, screenW, screenH);
    return 0;
}
