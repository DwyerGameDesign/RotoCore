#include "pd_api.h"
#include "c_particle.h"
#include "c_enemy.h"
#include "c_collision.h"
#include "c_shield.h"
#include "c_grid_ripple.h"
#include "c_starfield.h"
#include "c_laser.h"

static PlaydateAPI* pd = NULL;

#ifdef _WINDLL
__declspec(dllexport)
#endif
int eventHandler(PlaydateAPI* playdate, PDSystemEvent event, uint32_t arg) {
    (void)arg;
    pd = playdate;

    if (event == kEventInitLua) {
        /* --- initialise subsystems --- */
        particle_init(pd);
        enemy_init(pd);
        collision_init(pd);
        shield_init(pd);
        grid_ripple_init(pd);
        starfield_init(pd);
        laser_init(pd);

        /* --- register particle functions --- */
        pd->lua->addFunction(c_particle_update_lua,    "c_particle_update",    NULL);
        pd->lua->addFunction(c_particle_add_burst_lua, "c_particle_add_burst", NULL);
        pd->lua->addFunction(c_particle_clear_lua,     "c_particle_clear",     NULL);
        pd->lua->addFunction(c_particle_get_count_lua, "c_particle_get_count", NULL);
        pd->lua->addFunction(c_particle_draw_lua,      "c_particle_draw",      NULL);

        /* --- register enemy functions --- */
        pd->lua->addFunction(c_enemy_update_lua,            "c_enemy_update",            NULL);
        pd->lua->addFunction(c_enemy_add_lua,               "c_enemy_add",               NULL);
        pd->lua->addFunction(c_enemy_remove_lua,            "c_enemy_remove",            NULL);
        pd->lua->addFunction(c_enemy_clear_lua,             "c_enemy_clear",             NULL);
        pd->lua->addFunction(c_enemy_get_count_lua,         "c_enemy_get_count",         NULL);
        pd->lua->addFunction(c_enemy_get_lua,               "c_enemy_get",               NULL);
        pd->lua->addFunction(c_enemy_set_health_lua,        "c_enemy_set_health",        NULL);
        pd->lua->addFunction(c_enemy_set_destroyed_lua,     "c_enemy_set_destroyed",     NULL);
        pd->lua->addFunction(c_enemy_get_hex_spawn_lua,     "c_enemy_get_hex_spawn",     NULL);
        pd->lua->addFunction(c_enemy_freeze_all_lua,        "c_enemy_freeze_all",        NULL);
        pd->lua->addFunction(c_enemy_freeze_all_timed_lua, "c_enemy_freeze_all_timed",  NULL);
        pd->lua->addFunction(c_enemy_get_death_lua,        "c_enemy_get_death",         NULL);
        pd->lua->addFunction(c_enemy_get_health_lua,       "c_enemy_get_health",        NULL);
        pd->lua->addFunction(c_enemy_draw_all_lua,         "c_enemy_draw_all",          NULL);

        /* --- register collision functions --- */
        pd->lua->addFunction(c_collision_check_all_lua,          "c_collision_check_all",          NULL);
        pd->lua->addFunction(c_collision_check_core_lua,         "c_collision_check_core",         NULL);
        pd->lua->addFunction(c_collision_check_enemy_core_lua,   "c_collision_check_enemy_core",   NULL);
        pd->lua->addFunction(c_collision_apply_wave_damage_lua,   "c_collision_apply_wave_damage",   NULL);
        pd->lua->addFunction(c_collision_apply_pulse_radial_nudge_lua, "c_collision_apply_pulse_radial_nudge", NULL);

        /* --- register shield functions --- */
        pd->lua->addFunction(c_shield_add_lua,            "c_shield_add",            NULL);
        pd->lua->addFunction(c_shield_update_lua,         "c_shield_update",         NULL);
        pd->lua->addFunction(c_shield_get_collision_lua,  "c_shield_get_collision",  NULL);
        pd->lua->addFunction(c_shield_clear_lua,          "c_shield_clear",          NULL);
        pd->lua->addFunction(c_shield_clear_type_lua,     "c_shield_clear_type",     NULL);
        pd->lua->addFunction(c_shield_get_count_lua,      "c_shield_get_count",      NULL);
        pd->lua->addFunction(c_shield_get_lua,            "c_shield_get",            NULL);

        /* --- register grid ripple functions --- */
        pd->lua->addFunction(c_grid_ripple_add_lua,    "c_grid_ripple_add",    NULL);
        pd->lua->addFunction(c_grid_ripple_add_inward_lua, "c_grid_ripple_add_inward", NULL);
        pd->lua->addFunction(c_grid_ripple_set_exclude_zone_lua, "c_grid_ripple_set_exclude_zone", NULL);
        pd->lua->addFunction(c_grid_ripple_draw_lua,   "c_grid_ripple_draw",   NULL);
        pd->lua->addFunction(c_grid_ripple_clear_lua,  "c_grid_ripple_clear",  NULL);
        pd->lua->addFunction(c_grid_ripple_dissolve_lua,        "c_grid_ripple_dissolve",        NULL);
        pd->lua->addFunction(c_grid_ripple_reset_dissolve_lua, "c_grid_ripple_reset_dissolve", NULL);
        pd->lua->addFunction(c_grid_ripple_materialize_lua,    "c_grid_ripple_materialize",    NULL);

        /* --- starfield --- */
        pd->lua->addFunction(c_starfield_populate_lua, "c_starfield_populate", NULL);
        pd->lua->addFunction(c_starfield_update_lua,   "c_starfield_update",   NULL);
        pd->lua->addFunction(c_starfield_draw_lua,     "c_starfield_draw",     NULL);
        pd->lua->addFunction(c_starfield_clear_lua,    "c_starfield_clear",    NULL);

        /* --- laser draw --- */
        pd->lua->addFunction(c_laser_draw_lua, "c_laser_draw", NULL);
    }

    return 0;
}
