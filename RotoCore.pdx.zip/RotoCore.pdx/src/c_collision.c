#include "c_collision.h"
#include "c_enemy.h"
#include <math.h>

#define PI_F    3.14159265f
#define HALF_PI (PI_F * 0.5f)

static PlaydateAPI* pd = NULL;

typedef struct {
    float tipX, tipY;
    float dirX, dirY;
    float startWidth, endWidth;
    float range;
} LaserInfo;

/* Cached each frame by collision_check_all so collision_check_core can reuse */
static LaserInfo cachedMain;
static LaserInfo cachedReverse;
static int       cachedHasReverse = 0;
static float     cachedMainDamage = 0.0f;
static float     cachedReverseDamage = 0.0f;

void collision_init(PlaydateAPI* playdate) {
    pd = playdate;
}

/* ---- internal: check one target against one laser ---- */
static int check_laser_hit(float targetX, float targetY, float targetRadius,
                           const LaserInfo* laser) {
    /* visibility: bounding-box vs screen */
    if (targetX + targetRadius < 0 || targetX - targetRadius > SCREEN_WIDTH) return 0;
    if (targetY + targetRadius < 0 || targetY - targetRadius > SCREEN_HEIGHT) return 0;

    float dx = targetX - laser->tipX;
    float dy = targetY - laser->tipY;
    float distSq = dx * dx + dy * dy;

    if (distSq < 1.0f) return 0;

    float maxDist = laser->range + targetRadius;
    if (distSq > maxDist * maxDist) return 0;

    float dot = dx * laser->dirX + dy * laser->dirY;
    if (dot < -targetRadius) return 0;

    /* width at this distance */
    float progress = dot > 0 ? (dot / laser->range) : 0.0f;
    if (progress > 1.0f) progress = 1.0f;
    float width = laser->startWidth + (laser->endWidth - laser->startWidth) * progress;

    float perp = dx * laser->dirY - dy * laser->dirX;
    if (perp < 0) perp = -perp;

    return perp < (width * 0.5f + targetRadius);
}

/* ---- public ---- */

void collision_check_all(float playerX, float playerY, float playerRotation,
                         float playerSize, float damage,
                         float startWidth, float endWidth,
                         int hasReverseLaser, float reverseDamage,
                         float reverseStartWidth, float reverseEndWidth,
                         float laserRange,
                         uint32_t currentTime, int deathAnimActive,
                         float pulseKnockbackPx) {
    if (deathAnimActive) return;

    float range = (laserRange > 0.0f) ? laserRange : LASER_RANGE;

    /* --- build main laser info --- */
    float dir = playerRotation + HALF_PI;
    cachedMain.tipX = playerX + cosf(dir) * playerSize;
    cachedMain.tipY = playerY + sinf(dir) * playerSize;
    cachedMain.dirX = cosf(dir);
    cachedMain.dirY = sinf(dir);
    cachedMain.startWidth = startWidth;
    cachedMain.endWidth   = endWidth;
    cachedMain.range      = range;
    cachedMainDamage      = damage;

    /* --- build reverse laser info --- */
    cachedHasReverse  = hasReverseLaser;
    cachedReverseDamage = reverseDamage;
    if (hasReverseLaser) {
        float rdir = playerRotation + HALF_PI + PI_F;
        cachedReverse.tipX = playerX + cosf(rdir) * playerSize;
        cachedReverse.tipY = playerY + sinf(rdir) * playerSize;
        cachedReverse.dirX = cosf(rdir);
        cachedReverse.dirY = sinf(rdir);
        cachedReverse.startWidth = reverseStartWidth;
        cachedReverse.endWidth   = reverseEndWidth;
        cachedReverse.range      = range;
    }

    /* --- broadphase constants --- */
    float mainMaxHW = startWidth > endWidth
                    ? startWidth * 0.5f : endWidth * 0.5f;
    float revMaxHW = 0;
    if (hasReverseLaser)
        revMaxHW = reverseStartWidth > reverseEndWidth
                 ? reverseStartWidth * 0.5f : reverseEndWidth * 0.5f;

    /* --- iterate enemies --- */
    int count;
    Enemy* arr = enemy_get_array(&count);

    for (int i = 0; i < count; i++) {
        Enemy* e = &arr[i];
        if (e->destroyed || e->health <= 0) continue;

        float r = e->radius;

        /* main laser broadphase */
        float mdx = e->x - cachedMain.tipX;
        float mdy = e->y - cachedMain.tipY;
        float mdot = mdx * cachedMain.dirX + mdy * cachedMain.dirY;
        if (mdot >= -r) {
            float mperp = mdx * cachedMain.dirY - mdy * cachedMain.dirX;
            if (mperp < 0) mperp = -mperp;
            if (mperp < mainMaxHW + r) {
                if (check_laser_hit(e->x, e->y, r, &cachedMain)) {
                    e->health -= damage;
                    e->impactSlowdown = IMPACT_SLOWDOWN_VALUE;
                    e->impactSlowdownUntil = currentTime + IMPACT_SLOWDOWN_DURATION;
                    if (pulseKnockbackPx > 0.0f) {
                        int isFrozen = (e->frozen != 0) || (e->frozenUntil > currentTime);
                        if (!isFrozen) {
                            /* Per-frame velocity injection during pulse window.
                               With *= 0.5f decay in enemy_update, steady-state velocity is 2*v0,
                               so steady-state per-frame displacement is 2*v0 ≈ 3px/frame.
                               Held in beam for full 8-frame pulse → ~25px total displacement.
                               Tracked briefly → proportionally less. Rewards tracking skill. */
                            float v0 = pulseKnockbackPx * 0.06f;
                            e->knockbackVx += cachedMain.dirX * v0;
                            e->knockbackVy += cachedMain.dirY * v0;
                        }
                    }
                }
            }
        }

        /* reverse laser broadphase */
        if (hasReverseLaser) {
            float rdx = e->x - cachedReverse.tipX;
            float rdy = e->y - cachedReverse.tipY;
            float rdot = rdx * cachedReverse.dirX + rdy * cachedReverse.dirY;
            if (rdot >= -r) {
                float rperp = rdx * cachedReverse.dirY - rdy * cachedReverse.dirX;
                if (rperp < 0) rperp = -rperp;
                if (rperp < revMaxHW + r) {
                    if (check_laser_hit(e->x, e->y, r, &cachedReverse)) {
                        e->health -= reverseDamage;
                        e->impactSlowdown = IMPACT_SLOWDOWN_VALUE;
                        e->impactSlowdownUntil = currentTime + IMPACT_SLOWDOWN_DURATION;
                    }
                }
            }
        }
    }
}

float collision_check_core(float coreX, float coreY, float coreRadius) {
    float totalDamage = 0.0f;

    if (check_laser_hit(coreX, coreY, coreRadius, &cachedMain))
        totalDamage += cachedMainDamage;

    if (cachedHasReverse && check_laser_hit(coreX, coreY, coreRadius, &cachedReverse))
        totalDamage += cachedReverseDamage;

    return totalDamage;
}

int collision_check_enemy_core(void) {
    int count;
    Enemy* arr = enemy_get_array(&count);
    float collisionRadius = CENTER_COLLISION_RADIUS;

    for (int i = 0; i < count; i++) {
        Enemy* e = &arr[i];
        if (e->destroyed) continue;

        float dx = e->x - CENTER_X;
        float dy = e->y - CENTER_Y;
        float distSq = dx * dx + dy * dy;
        float rSum = collisionRadius + e->radius;
        if (distSq < rSum * rSum)
            return i;
    }
    return -1;
}

static int apply_wave_damage_impl(float x, float y, float radius,
                                  float damage, uint32_t waveId,
                                  uint32_t currentTime) {
    if (waveId == 0) return 0;

    int count;
    Enemy* arr = enemy_get_array(&count);
    int hits = 0;

    for (int i = 0; i < count; i++) {
        Enemy* e = &arr[i];
        if (e->health <= 0 || e->destroyed) continue;
        if (e->lastHitWaveId == waveId) continue;

        float adx = fabsf(e->x - x);
        float ady = fabsf(e->y - y);
        if ((adx + ady) > (radius + e->radius + 50.0f)) continue;

        float dx = e->x - x;
        float dy = e->y - y;
        float distSq = dx * dx + dy * dy;
        float rSum = radius + e->radius;
        if (distSq <= rSum * rSum) {
            e->health -= damage;
            e->impactSlowdown = IMPACT_SLOWDOWN_VALUE;
            e->impactSlowdownUntil = currentTime + IMPACT_SLOWDOWN_DURATION;
            e->lastHitWaveId = waveId;
            hits++;
        }
    }

    return hits;
}

void collision_apply_pulse_radial_nudge(float originX, float originY,
                                        float radius, float pushPx,
                                        uint32_t currentTime) {
    int count;
    Enemy* arr = enemy_get_array(&count);
    for (int i = 0; i < count; i++) {
        Enemy* e = &arr[i];
        if (e->destroyed || e->health <= 0) continue;
        if (e->frozen != 0) continue;
        if (e->frozenUntil > currentTime) continue;

        float dx = e->x - originX;
        float dy = e->y - originY;

        float adx = dx < 0 ? -dx : dx;
        float ady = dy < 0 ? -dy : dy;
        if ((adx + ady) > (radius + e->radius + 20.0f)) continue;

        float distSq = dx * dx + dy * dy;
        float rSum = radius + e->radius;
        if (distSq > rSum * rSum) continue;

        float dist = sqrtf(distSq);
        float nx, ny;
        if (dist < 0.01f) {
            nx = 1.0f; ny = 0.0f;
        } else {
            nx = dx / dist;
            ny = dy / dist;
        }
        float v0 = pushPx * 0.5f;
        e->knockbackVx += nx * v0;
        e->knockbackVy += ny * v0;
    }
}

void collision_apply_wave_damage(float x, float y, float radius,
                                 float damage, uint32_t waveId,
                                 uint32_t currentTime) {
    (void)apply_wave_damage_impl(x, y, radius, damage, waveId, currentTime);
}

/* ========== Lua-callable wrappers ========== */

int c_collision_check_all_lua(lua_State* L) {
    float    px   = pd->lua->getArgFloat(1);
    float    py   = pd->lua->getArgFloat(2);
    float    prot = pd->lua->getArgFloat(3);
    float    psz  = pd->lua->getArgFloat(4);
    float    dmg  = pd->lua->getArgFloat(5);
    float    sw   = pd->lua->getArgFloat(6);
    float    ew   = pd->lua->getArgFloat(7);
    int      rev  = pd->lua->getArgBool(8);
    float    rdmg = pd->lua->getArgFloat(9);
    float    rsw  = pd->lua->getArgFloat(10);
    float    rew  = pd->lua->getArgFloat(11);
    float    lrng = pd->lua->getArgFloat(12);
    uint32_t ct   = (uint32_t)pd->lua->getArgInt(13);
    int      da   = pd->lua->getArgBool(14);
    float    kb   = pd->lua->getArgFloat(15);

    collision_check_all(px, py, prot, psz, dmg, sw, ew,
                        rev, rdmg, rsw, rew, lrng, ct, da, kb);
    return 0;
}

int c_collision_apply_pulse_radial_nudge_lua(lua_State* L) {
    float    x      = pd->lua->getArgFloat(1);
    float    y      = pd->lua->getArgFloat(2);
    float    radius = pd->lua->getArgFloat(3);
    float    push   = pd->lua->getArgFloat(4);
    uint32_t ct     = (uint32_t)pd->lua->getArgInt(5);
    collision_apply_pulse_radial_nudge(x, y, radius, push, ct);
    return 0;
}

int c_collision_check_core_lua(lua_State* L) {
    float cx = pd->lua->getArgFloat(1);
    float cy = pd->lua->getArgFloat(2);
    float cr = pd->lua->getArgFloat(3);

    float d = collision_check_core(cx, cy, cr);
    pd->lua->pushFloat(d);
    return 1;
}

int c_collision_check_enemy_core_lua(lua_State* L) {
    int idx = collision_check_enemy_core();
    pd->lua->pushInt(idx);
    return 1;
}

int c_collision_apply_wave_damage_lua(lua_State* L) {
    float    x      = pd->lua->getArgFloat(1);
    float    y      = pd->lua->getArgFloat(2);
    float    radius = pd->lua->getArgFloat(3);
    float    damage = pd->lua->getArgFloat(4);
    uint32_t waveId = (uint32_t)pd->lua->getArgInt(5);
    uint32_t ct     = (uint32_t)pd->lua->getArgInt(6);

    collision_apply_wave_damage(x, y, radius, damage, waveId, ct);
    return 0;
}
