#ifndef C_LASER_H
#define C_LASER_H

#include "pd_api.h"

void laser_init(PlaydateAPI* playdate);

void laser_draw(
    float playerX, float playerY, float rotation, float playerSize,
    float tipOffset, float laserLength, float startWidth, float endWidth,
    float damageMultiplier, int poweredUpLaser, uint32_t currentTime,
    int reverseLaserActive, float reverseStartWidth, float reverseEndWidth,
    float reverseDamageMultiplier, float reverseTipOffset,
    float ditherPercent, float reverseDitherPercent);

int c_laser_draw_lua(lua_State* L);

#endif
