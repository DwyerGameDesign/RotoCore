#ifndef C_ENEMY_H
#define C_ENEMY_H

#include "pd_api.h"
#include <stdint.h>
#include <stdbool.h>

#define MAX_ENEMIES       128
#define MAX_HEX_SPAWNS    16

#define CENTER_X          200.0f
#define CENTER_Y          120.0f
#define CENTER_DANGER_RADIUS    14.0f
#define CENTER_DANGER_RADIUS_SQ (CENTER_DANGER_RADIUS * CENTER_DANGER_RADIUS)
#define CENTER_COLLISION_RADIUS 8.0f

#define SCREEN_WIDTH  400
#define SCREEN_HEIGHT 240

#define HEXAGON_SPAWN_INTERVAL 3000
#define TIME_DILATION_FACTOR   0.15f

#define MAX_VERTEX_COORDS 12  /* 6 sides × 2 coords (x,y) */

typedef enum {
    ENEMY_DIAMOND  = 0,
    ENEMY_CIRCLE   = 1,
    ENEMY_SQUARE   = 2,
    ENEMY_PENTAGON = 3,
    ENEMY_HEXAGON  = 4
} EnemyType;

typedef struct {
    float x, y;
    float speed;
    float rotation;
    float rotationSpeed;
    float impactSlowdown;
    uint32_t impactSlowdownUntil;
    float knockbackVx;             /* per-frame x-velocity from pulse knockback; decays each frame */
    float knockbackVy;             /* per-frame y-velocity from pulse knockback; decays each frame */
    uint32_t frozenUntil;          /* 0 = no timed freeze */
    float radius;
    float healthMultiplier;
    float health;
    float maxHealth;
    int sides;
    int points;
    uint32_t lastSpawnTime;
    uint32_t id;                   /* unique stable identifier */
    uint32_t lastHitWaveId;        /* most recent blast wave id that damaged this enemy (0 = none) */
    uint8_t typeName;              /* EnemyType enum */
    uint8_t frozen;                /* permanent freeze (death animation) */
    uint8_t destroyed;
    uint8_t hardened;

    float vertices[MAX_VERTEX_COORDS];  /* pre-computed screen-space vertex coords */
    int vertexCount;                     /* 0 for circles */
} Enemy;

typedef struct {
    float x, y;
    float dx, dy;                  /* direction to center for perp calc */
} HexSpawnInfo;

void    enemy_init(PlaydateAPI* playdate);
int     enemy_update(uint32_t currentTime, float timeScale, int timeDilationActive);
int     enemy_add(float x, float y, float speed, float rotation, float rotationSpeed,
                  float radius, int sides, int typeName, float health, float maxHealth,
                  float healthMultiplier, int hardened, int points, uint32_t lastSpawnTime);
void    enemy_remove(int index);
void    enemy_clear(void);
int     enemy_get_count(void);
Enemy*  enemy_get_ptr(int index);
void    enemy_freeze_all(void);
void    enemy_freeze_all_timed(uint32_t frozenUntil);

Enemy*  enemy_get_array(int* outCount);
const HexSpawnInfo* enemy_get_hex_spawn(int index);

void enemy_draw_all(uint32_t currentTime, int deathEnemyIndex, int screenW, int screenH);

/* Lua-callable wrappers */
int c_enemy_update_lua(lua_State* L);
int c_enemy_add_lua(lua_State* L);
int c_enemy_remove_lua(lua_State* L);
int c_enemy_clear_lua(lua_State* L);
int c_enemy_get_count_lua(lua_State* L);
int c_enemy_get_lua(lua_State* L);
int c_enemy_set_health_lua(lua_State* L);
int c_enemy_set_destroyed_lua(lua_State* L);
int c_enemy_get_hex_spawn_lua(lua_State* L);
int c_enemy_freeze_all_lua(lua_State* L);
int c_enemy_freeze_all_timed_lua(lua_State* L);
int c_enemy_get_death_lua(lua_State* L);
int c_enemy_get_health_lua(lua_State* L);
int c_enemy_draw_all_lua(lua_State* L);

#endif
