#ifndef C_PARTICLE_H
#define C_PARTICLE_H

#include "pd_api.h"

#define MAX_PARTICLES 100

typedef struct {
    float x, y;
    float vx, vy;
    int life;
    int maxLife;
} Particle;

void particle_init(PlaydateAPI* playdate);
void particle_update(float timeScale);
int  particle_add_burst(float x, float y, int count, float scale, int life);
void particle_clear(void);
int  particle_get_count(void);

void particle_draw(PlaydateAPI* pd);

int c_particle_update_lua(lua_State* L);
int c_particle_add_burst_lua(lua_State* L);
int c_particle_clear_lua(lua_State* L);
int c_particle_get_count_lua(lua_State* L);
int c_particle_draw_lua(lua_State* L);

#endif
